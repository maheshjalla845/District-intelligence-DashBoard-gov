import { pgTable, text, serial, real, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const districtsTable = pgTable("districts", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().default("guntur"),
  name: text("name").notNull(),
  tagline: text("tagline").notNull(),
  tags: jsonb("tags").$type<string[]>().notNull().default([]),
  population: real("population").notNull(),
  area: real("area").notNull(),
  literacy: real("literacy").notNull(),
  mandals: integer("mandals").notNull(),
  headquarters: text("headquarters").notNull(),
  established: text("established").notNull(),
  famousPeople: jsonb("famous_people").$type<string[]>().notNull().default([]),
});

export const insertDistrictSchema = createInsertSchema(districtsTable).omit({ id: true });
export type InsertDistrict = z.infer<typeof insertDistrictSchema>;
export type District = typeof districtsTable.$inferSelect;

export const mandalsTable = pgTable("mandals", {
  id: text("id").primaryKey(),
  district: text("district").notNull().default("guntur"),
  name: text("name").notNull(),
  population: real("population").notNull(),
  area: real("area").notNull(),
  tags: jsonb("tags").$type<string[]>().notNull().default([]),
  type: text("type").notNull(),
});

export const insertMandalSchema = createInsertSchema(mandalsTable);
export type InsertMandal = z.infer<typeof insertMandalSchema>;
export type Mandal = typeof mandalsTable.$inferSelect;

export const alertsTable = pgTable("alerts", {
  id: text("id").primaryKey(),
  district: text("district").notNull().default("guntur"),
  title: text("title").notNull(),
  description: text("description").notNull(),
  severity: text("severity").notNull(),
  category: text("category").notNull(),
  issuedAt: timestamp("issued_at").notNull().defaultNow(),
  validUntil: timestamp("valid_until"),
});

export const insertAlertSchema = createInsertSchema(alertsTable);
export type InsertAlert = z.infer<typeof insertAlertSchema>;
export type Alert = typeof alertsTable.$inferSelect;

export const newsTable = pgTable("news", {
  id: text("id").primaryKey(),
  district: text("district").notNull().default("guntur"),
  headline: text("headline").notNull(),
  summary: text("summary").notNull(),
  source: text("source").notNull(),
  category: text("category").notNull(),
  publishedAt: timestamp("published_at").notNull().defaultNow(),
  url: text("url"),
});

export const insertNewsSchema = createInsertSchema(newsTable);
export type InsertNews = z.infer<typeof insertNewsSchema>;
export type News = typeof newsTable.$inferSelect;

export const mandiPricesTable = pgTable("mandi_prices", {
  id: text("id").primaryKey(),
  district: text("district").notNull().default("guntur"),
  crop: text("crop").notNull(),
  variety: text("variety").notNull(),
  price: real("price").notNull(),
  unit: text("unit").notNull(),
  market: text("market").notNull(),
  change: real("change").notNull().default(0),
  changePercent: real("change_percent").notNull().default(0),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertMandiPriceSchema = createInsertSchema(mandiPricesTable);
export type InsertMandiPrice = z.infer<typeof insertMandiPriceSchema>;
export type MandiPrice = typeof mandiPricesTable.$inferSelect;

export const citizenServicesTable = pgTable("citizen_services", {
  id: text("id").primaryKey(),
  district: text("district").notNull().default("guntur"),
  name: text("name").notNull(),
  category: text("category").notNull(),
  description: text("description").notNull(),
  url: text("url"),
  icon: text("icon").notNull(),
  status: text("status").notNull().default("online"),
  phone: text("phone").notNull().default("1800-XXX-XXXX"),
  officeHours: text("office_hours").notNull().default("Mon-Sat 10:00 AM – 5:00 PM"),
  applicationsThisMonth: integer("applications_this_month").notNull().default(0),
  pendingApplications: integer("pending_applications").notNull().default(0),
  avgResponseDays: real("avg_response_days").notNull().default(5),
  totalProcessed: integer("total_processed").notNull().default(0),
  satisfactionScore: real("satisfaction_score").notNull().default(4.0),
});

export const insertCitizenServiceSchema = createInsertSchema(citizenServicesTable);
export type InsertCitizenService = z.infer<typeof insertCitizenServiceSchema>;
export type CitizenService = typeof citizenServicesTable.$inferSelect;
