import { useGetInfrastructure, getGetInfrastructureQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { DataSource } from "@/components/data-source";
import { Construction, IndianRupee, MapPin, Calendar, Building2, HardHat } from "lucide-react";
import { useDistrict } from "@/contexts/district-context";

const statusBadge: Record<string, string> = {
  completed: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
  ongoing: "bg-cyan-500/15 text-cyan-300 border-cyan-500/30",
  planned: "bg-slate-500/15 text-slate-300 border-slate-500/30",
  delayed: "bg-red-500/15 text-red-300 border-red-500/30",
};

const statusBar: Record<string, string> = {
  completed: "bg-emerald-400",
  ongoing: "bg-cyan-400",
  planned: "bg-slate-400",
  delayed: "bg-red-400",
};

const conditionMeta: Record<string, { color: string; bg: string; bar: string }> = {
  excellent: { color: "text-emerald-300", bg: "bg-emerald-500/10 border-emerald-500/30", bar: "bg-emerald-400" },
  good: { color: "text-cyan-300", bg: "bg-cyan-500/10 border-cyan-500/30", bar: "bg-cyan-400" },
  fair: { color: "text-amber-300", bg: "bg-amber-500/10 border-amber-500/30", bar: "bg-amber-400" },
  poor: { color: "text-orange-300", bg: "bg-orange-500/10 border-orange-500/30", bar: "bg-orange-400" },
  critical: { color: "text-red-300", bg: "bg-red-500/10 border-red-500/30", bar: "bg-red-400" },
};

const typeIcon: Record<string, typeof Building2> = {
  road: Construction,
  bridge: Construction,
  building: Building2,
  water: HardHat,
  irrigation: HardHat,
  public: HardHat,
};

export default function Infrastructure() {
  const { district } = useDistrict();
  const params = { district };
  const { data, isLoading } = useGetInfrastructure(params, { query: { queryKey: getGetInfrastructureQueryKey(params) } });

  if (isLoading || !data) {
    return (
      <div className="flex items-center justify-center h-64 text-muted-foreground font-mono text-sm tracking-widest animate-pulse">
        LOADING INFRASTRUCTURE DATA...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Total Projects</p>
            <p className="text-2xl font-bold text-primary font-mono mt-1">{data.summary.totalProjects}</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Ongoing</p>
            <p className="text-2xl font-bold text-cyan-300 font-mono mt-1">{data.summary.ongoing}</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Completed</p>
            <p className="text-2xl font-bold text-emerald-300 font-mono mt-1">{data.summary.completed}</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Delayed</p>
            <p className="text-2xl font-bold text-red-300 font-mono mt-1">{data.summary.delayed}</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Planned</p>
            <p className="text-2xl font-bold text-slate-300 font-mono mt-1">{data.summary.planned}</p>
          </CardContent>
        </Card>
      </div>

      {/* Budget block */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest flex items-center gap-2">
            <IndianRupee className="w-4 h-4 text-primary" /> Budget vs Utilization
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="rounded-lg bg-background/50 border border-border/40 p-4">
              <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Total Budget</p>
              <p className="text-2xl font-bold text-cyan-300 font-mono mt-1">₹{data.summary.totalBudgetCrore.toLocaleString("en-IN")} <span className="text-sm">Cr</span></p>
            </div>
            <div className="rounded-lg bg-background/50 border border-border/40 p-4">
              <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Utilized</p>
              <p className="text-2xl font-bold text-emerald-300 font-mono mt-1">₹{data.summary.totalUtilizedCrore.toLocaleString("en-IN")} <span className="text-sm">Cr</span></p>
            </div>
            <div className="rounded-lg bg-background/50 border border-border/40 p-4">
              <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Utilization %</p>
              <p className="text-2xl font-bold text-fuchsia-300 font-mono mt-1">{data.summary.utilizationPercent}%</p>
              <Progress value={data.summary.utilizationPercent} className="h-1.5 mt-2" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Project Timeline */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest">Project Timeline & Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {data.projects.map((p) => {
              const Icon = typeIcon[p.type] ?? Building2;
              const utilPct = Math.round((p.utilizedCrore / p.budgetCrore) * 100) || 0;
              return (
                <div key={p.id} className="relative pl-6">
                  <div className={`absolute left-0 top-2 w-3 h-3 rounded-full ${statusBar[p.status]} ring-4 ring-background`} />
                  <div className="absolute left-1.5 top-5 bottom-0 w-px bg-border/50" />
                  <div className="rounded-lg border border-border/40 bg-background/40 p-4 mb-1">
                    <div className="flex flex-wrap items-start gap-2 mb-3">
                      <Icon className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                      <p className="font-semibold text-sm flex-1">{p.name}</p>
                      <Badge variant="outline" className="text-[10px] font-mono uppercase">{p.type}</Badge>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${statusBadge[p.status]}`}>{p.status}</span>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono mb-3">
                      <span className="flex items-center gap-1 text-muted-foreground">
                        <MapPin className="w-3 h-3" /> {p.location}
                      </span>
                      <span className="flex items-center gap-1 text-muted-foreground">
                        <Calendar className="w-3 h-3" /> {p.startDate} → {p.endDate}
                      </span>
                      <span className="text-cyan-300">Budget: ₹{p.budgetCrore} Cr</span>
                      <span className="text-emerald-300">Used: ₹{p.utilizedCrore} Cr ({utilPct}%)</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Progress value={p.progress} className="h-1.5 flex-1" />
                      <span className="text-xs font-mono text-muted-foreground w-12 text-right">{p.progress}%</span>
                    </div>
                    <p className="text-[10px] text-muted-foreground/70 font-mono mt-2">Contractor: {p.contractor}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Road condition heatmap */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest">Road Condition Index</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-3 mb-5">
            <div className="rounded-lg bg-background/50 border border-border/40 p-3">
              <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Total Network</p>
              <p className="text-lg font-bold text-cyan-300 font-mono">{data.roadSummary.totalKm} km</p>
            </div>
            <div className="rounded-lg bg-background/50 border border-border/40 p-3">
              <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Average Score</p>
              <p className="text-lg font-bold text-emerald-300 font-mono">{data.roadSummary.avgScore}/100</p>
            </div>
            <div className="rounded-lg bg-background/50 border border-border/40 p-3">
              <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Critical / Poor</p>
              <p className="text-lg font-bold text-red-300 font-mono">{data.roadSummary.criticalKm} km</p>
            </div>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {data.roadConditions.map((r) => {
              const meta = conditionMeta[r.condition];
              return (
                <div key={r.area} className={`rounded-lg border p-3 ${meta.bg}`}>
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm font-semibold text-foreground">{r.area}</p>
                    <span className={`text-[10px] font-mono uppercase ${meta.color}`}>{r.condition}</span>
                  </div>
                  <div className="h-2 rounded-full bg-background overflow-hidden mb-2">
                    <div className={`h-full ${meta.bar}`} style={{ width: `${r.score}%` }} />
                  </div>
                  <div className="flex justify-between text-[11px] font-mono text-muted-foreground">
                    <span>{r.lengthKm} km</span>
                    <span>{r.score}/100</span>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <DataSource
        lastUpdated={data.lastUpdated}
        sources={[
          { name: "AP Roads & Buildings Department", url: "https://aprbroads.ap.gov.in", note: "Project data" },
          { name: "Pradhan Mantri Gram Sadak Yojana", url: "https://omms.nic.in", note: "Rural roads" },
          { name: "NHAI", url: "https://nhai.gov.in", note: "National Highways in district" },
          { name: "Guntur Smart City Mission", note: "Urban infrastructure projects" },
        ]}
      />
    </div>
  );
}
