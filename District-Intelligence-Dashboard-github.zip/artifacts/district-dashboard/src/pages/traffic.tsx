import { useGetTraffic, getGetTrafficQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DataSource } from "@/components/data-source";
import { Activity, Car, Clock, AlertTriangle, MapPin, Gauge } from "lucide-react";
import { useDistrict } from "@/contexts/district-context";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const levelColor: Record<string, string> = {
  low: "text-emerald-300",
  moderate: "text-amber-300",
  high: "text-orange-300",
  severe: "text-red-300",
};

const levelBg: Record<string, string> = {
  low: "bg-emerald-500/10 border-emerald-500/30",
  moderate: "bg-amber-500/10 border-amber-500/30",
  high: "bg-orange-500/10 border-orange-500/30",
  severe: "bg-red-500/10 border-red-500/30",
};

const severityBadge: Record<string, string> = {
  low: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
  medium: "bg-amber-500/15 text-amber-300 border-amber-500/30",
  high: "bg-red-500/15 text-red-300 border-red-500/30",
};

function congestionTone(c: number): string {
  if (c >= 75) return "bg-red-500/80";
  if (c >= 55) return "bg-orange-500/80";
  if (c >= 35) return "bg-amber-500/70";
  return "bg-emerald-500/70";
}

function congestionTextTone(c: number): string {
  if (c >= 75) return "text-red-300";
  if (c >= 55) return "text-orange-300";
  if (c >= 35) return "text-amber-300";
  return "text-emerald-300";
}

export default function Traffic() {
  const { district } = useDistrict();
  const params = { district };
  const { data, isLoading } = useGetTraffic(params, { query: { queryKey: getGetTrafficQueryKey(params) } });

  if (isLoading || !data) {
    return (
      <div className="flex items-center justify-center h-64 text-muted-foreground font-mono text-sm tracking-widest animate-pulse">
        LOADING TRAFFIC DATA...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Hero */}
      <Card className={`border ${levelBg[data.congestionLevel]}`}>
        <CardContent className="p-6">
          <div className="flex flex-wrap items-center gap-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-background/50 border border-border flex items-center justify-center">
                <Gauge className={`w-8 h-8 ${levelColor[data.congestionLevel]}`} />
              </div>
              <div>
                <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Live Congestion</p>
                <p className={`text-4xl font-bold font-mono ${levelColor[data.congestionLevel]}`}>
                  {data.currentCongestion}%
                </p>
                <p className={`text-xs uppercase font-mono tracking-widest mt-1 ${levelColor[data.congestionLevel]}`}>{data.congestionLevel} traffic</p>
              </div>
            </div>
            <div className="hidden md:block w-px h-16 bg-border" />
            <div className="flex items-center gap-3">
              <Car className="w-6 h-6 text-cyan-300" />
              <div>
                <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Avg Speed</p>
                <p className="text-2xl font-bold text-cyan-300 font-mono">{data.avgSpeed} <span className="text-sm">km/h</span></p>
              </div>
            </div>
            <div className="hidden md:block w-px h-16 bg-border" />
            <div className="flex items-center gap-3">
              <Clock className="w-6 h-6 text-fuchsia-300" />
              <div>
                <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Peak Hours</p>
                <p className="text-sm font-semibold text-foreground font-mono">{data.peakHours.join(" · ")}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Hourly chart */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest flex items-center gap-2">
            <Activity className="w-4 h-4 text-primary" /> 24-Hour Congestion Trend
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.hourlyTrend} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                <defs>
                  <linearGradient id="congGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
                <XAxis dataKey="hour" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} interval={1} />
                <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} unit="%" />
                <Tooltip
                  contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }}
                  formatter={(v: number) => [`${v}%`, "Congestion"]}
                />
                <Area type="monotone" dataKey="congestion" stroke="#f59e0b" fill="url(#congGrad)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Heatmap grid */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest">Road Congestion Heatmap</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
            {data.heatmap.map((p) => (
              <div key={p.area} className="rounded-lg border border-border/40 bg-background/40 p-3">
                <div className="flex items-start justify-between mb-2 gap-2">
                  <p className="text-xs font-semibold text-foreground truncate">{p.area}</p>
                  <span className={`text-xs font-bold font-mono ${congestionTextTone(p.congestion)}`}>{p.congestion}%</span>
                </div>
                <div className="h-2 rounded-full bg-background overflow-hidden mb-2">
                  <div className={`h-full transition-all duration-500 ${congestionTone(p.congestion)}`} style={{ width: `${p.congestion}%` }} />
                </div>
                <div className="flex justify-between text-[10px] font-mono text-muted-foreground">
                  <span>{p.condition}</span>
                  <span>{p.speed} km/h</span>
                </div>
              </div>
            ))}
          </div>
          <div className="flex items-center gap-3 mt-4 text-[10px] font-mono text-muted-foreground">
            <span className="flex items-center gap-1"><span className="w-3 h-2 rounded-sm bg-emerald-500/70" /> Free flow</span>
            <span className="flex items-center gap-1"><span className="w-3 h-2 rounded-sm bg-amber-500/70" /> Slow</span>
            <span className="flex items-center gap-1"><span className="w-3 h-2 rounded-sm bg-orange-500/80" /> Heavy</span>
            <span className="flex items-center gap-1"><span className="w-3 h-2 rounded-sm bg-red-500/80" /> Jammed</span>
          </div>
        </CardContent>
      </Card>

      {/* Incidents */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-300" /> Live Incidents
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {data.incidents.map((inc, i) => (
              <div key={i} className="flex items-center gap-3 p-3 rounded-lg border border-border/40 bg-background/40">
                <MapPin className="w-4 h-4 text-muted-foreground shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground truncate">{inc.location}</p>
                  <p className="text-[11px] text-muted-foreground font-mono">{inc.type}</p>
                </div>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${severityBadge[inc.severity]}`}>{inc.severity}</span>
                <Badge variant="outline" className="text-[10px] font-mono">{inc.eta}</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <DataSource
        lastUpdated={data.lastUpdated}
        sources={[
          { name: "AP Traffic Police", url: "https://appolice.gov.in", note: "Incident reports" },
          { name: "Guntur Traffic Control Room", note: "Live road conditions" },
          { name: "Google Maps Traffic API", note: "Congestion baseline" },
          { name: "NHAI Toll Plaza Data", url: "https://nhai.gov.in", note: "Highway flow" },
        ]}
      />
    </div>
  );
}
