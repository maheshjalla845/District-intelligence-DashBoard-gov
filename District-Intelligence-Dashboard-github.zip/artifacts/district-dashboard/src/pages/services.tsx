import { useGetServices, getGetServicesQueryKey } from "@workspace/api-client-react";
import { useDistrict } from "@/contexts/district-context";
import { openUrl } from "@/lib/open-url";
import { Badge } from "@/components/ui/badge";
import {
  Bus, Droplets, Home, GraduationCap, FileText, Scale, Vote, IdCard,
  HeartPulse, Map, Wheat, Shield, Phone, Clock, TrendingUp, Users,
  CheckCircle, AlertTriangle, WrenchIcon, Star
} from "lucide-react";

const ICON_MAP: Record<string, React.ElementType> = {
  bus: Bus,
  droplets: Droplets,
  home: Home,
  "graduation-cap": GraduationCap,
  "file-text": FileText,
  scale: Scale,
  vote: Vote,
  "id-card": IdCard,
  "heart-pulse": HeartPulse,
  map: Map,
  wheat: Wheat,
  shield: Shield,
};

function StatusBadge({ status }: { status: string }) {
  if (status === "online") {
    return (
      <span className="flex items-center gap-1.5 text-[10px] font-mono font-semibold uppercase tracking-wider text-emerald-400">
        <span className="relative flex h-2 w-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
        </span>
        Online
      </span>
    );
  }
  if (status === "maintenance") {
    return (
      <span className="flex items-center gap-1.5 text-[10px] font-mono font-semibold uppercase tracking-wider text-amber-400">
        <WrenchIcon className="h-3 w-3" />
        Maintenance
      </span>
    );
  }
  return (
    <span className="flex items-center gap-1.5 text-[10px] font-mono font-semibold uppercase tracking-wider text-red-400">
      <AlertTriangle className="h-3 w-3" />
      Offline
    </span>
  );
}

function StatCell({ label, value, sub }: { label: string; value: string | number; sub?: string }) {
  return (
    <div className="flex flex-col gap-0.5">
      <span className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">{label}</span>
      <span className="text-sm font-semibold text-foreground leading-none">{value}</span>
      {sub && <span className="text-[10px] text-muted-foreground">{sub}</span>}
    </div>
  );
}

function SatisfactionBar({ score }: { score: number }) {
  const pct = (score / 5) * 100;
  const color = score >= 4.2 ? "bg-emerald-500" : score >= 3.5 ? "bg-cyan-500" : "bg-amber-500";
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden">
        <div className={`h-full rounded-full ${color}`} style={{ width: `${pct}%` }} />
      </div>
      <span className="text-xs font-semibold text-foreground tabular-nums">{score.toFixed(1)}</span>
      <Star className="h-3 w-3 text-amber-400 fill-amber-400" />
    </div>
  );
}

function fmt(n: number): string {
  if (n >= 100000) return `${(n / 100000).toFixed(1)}L`;
  if (n >= 1000) return `${(n / 1000).toFixed(1)}K`;
  return String(n);
}

export default function Services() {
  const { district } = useDistrict();
  const params = { district };
  const { data: services } = useGetServices(params, { query: { queryKey: getGetServicesQueryKey(params) } });

  const totalApps = services?.reduce((s, sv) => s + (sv.applicationsThisMonth ?? 0), 0) ?? 0;
  const totalPending = services?.reduce((s, sv) => s + (sv.pendingApplications ?? 0), 0) ?? 0;
  const onlineCount = services?.filter((sv) => sv.status === "online").length ?? 0;

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground font-mono uppercase tracking-tight">Citizen Services</h1>
          <p className="text-muted-foreground mt-1">Live status, volumes, and performance for all public service portals.</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="border border-border bg-card rounded-lg p-4 flex items-center gap-3">
          <div className="h-9 w-9 rounded-lg bg-emerald-500/10 flex items-center justify-center">
            <CheckCircle className="h-5 w-5 text-emerald-400" />
          </div>
          <div>
            <p className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">Services Online</p>
            <p className="text-2xl font-bold text-foreground">{onlineCount} <span className="text-sm text-muted-foreground font-normal">/ {services?.length ?? 0}</span></p>
          </div>
        </div>
        <div className="border border-border bg-card rounded-lg p-4 flex items-center gap-3">
          <div className="h-9 w-9 rounded-lg bg-cyan-500/10 flex items-center justify-center">
            <Users className="h-5 w-5 text-cyan-400" />
          </div>
          <div>
            <p className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">Applications This Month</p>
            <p className="text-2xl font-bold text-foreground">{fmt(totalApps)}</p>
          </div>
        </div>
        <div className="border border-border bg-card rounded-lg p-4 flex items-center gap-3">
          <div className="h-9 w-9 rounded-lg bg-amber-500/10 flex items-center justify-center">
            <TrendingUp className="h-5 w-5 text-amber-400" />
          </div>
          <div>
            <p className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">Pending Across All</p>
            <p className="text-2xl font-bold text-foreground">{fmt(totalPending)}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {services?.map((service) => {
          const Icon = ICON_MAP[service.icon] ?? IdCard;
          const isMaint = service.status === "maintenance";
          return (
            <div
              key={service.id}
              className={`border rounded-lg bg-card overflow-hidden transition-colors hover:bg-sidebar ${isMaint ? "border-amber-500/30" : "border-border"}`}
            >
              <div className="p-5 space-y-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <div className={`h-10 w-10 rounded-lg flex items-center justify-center shrink-0 ${isMaint ? "bg-amber-500/10" : "bg-primary/10"}`}>
                      <Icon className={`h-5 w-5 ${isMaint ? "text-amber-400" : "text-primary"}`} />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground leading-tight">{service.name}</h3>
                      <Badge variant="outline" className="text-[9px] font-mono uppercase border-muted-foreground/20 text-muted-foreground mt-0.5">
                        {service.category}
                      </Badge>
                    </div>
                  </div>
                  <StatusBadge status={service.status} />
                </div>

                <p className="text-xs text-muted-foreground leading-relaxed">{service.description}</p>

                <div className="grid grid-cols-3 gap-3 py-3 border-t border-b border-border/50">
                  <StatCell
                    label="This Month"
                    value={fmt(service.applicationsThisMonth ?? 0)}
                    sub="applications"
                  />
                  <StatCell
                    label="Pending"
                    value={service.pendingApplications === 0 ? "—" : fmt(service.pendingApplications ?? 0)}
                    sub="in queue"
                  />
                  <StatCell
                    label="Avg Response"
                    value={`${service.avgResponseDays ?? 0}d`}
                    sub="turnaround"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">Satisfaction</span>
                    <span className="text-[10px] text-muted-foreground">{fmt(service.totalProcessed ?? 0)} total processed</span>
                  </div>
                  <SatisfactionBar score={service.satisfactionScore ?? 0} />
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Phone className="h-3.5 w-3.5 shrink-0 text-primary/60" />
                    <span className="truncate font-mono">{service.phone}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Clock className="h-3.5 w-3.5 shrink-0 text-primary/60" />
                    <span className="truncate">{service.officeHours}</span>
                  </div>
                </div>
              </div>

              {service.url && (
                <button
                  onClick={() => service.url && openUrl(service.url)}
                  className="block w-full text-left px-5 py-2.5 bg-primary/5 hover:bg-primary/10 border-t border-border/50 text-[10px] font-mono uppercase tracking-wider text-primary transition-colors cursor-pointer"
                >
                  Visit Portal →
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
