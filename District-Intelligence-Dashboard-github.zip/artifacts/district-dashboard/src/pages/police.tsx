import {
  useGetPoliceSafety,
  getGetPoliceSafetyQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Phone, MapPin, TrendingUp, TrendingDown, Car, AlertTriangle } from "lucide-react";
import { openUrl } from "@/lib/open-url";
import { DataSource } from "@/components/data-source";
import { useDistrict } from "@/contexts/district-context";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

export default function Police() {
  const { district } = useDistrict();
  const params = { district };
  const { data, isLoading } = useGetPoliceSafety(params, {
    query: { queryKey: getGetPoliceSafetyQueryKey(params) },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64 text-muted-foreground font-mono text-sm tracking-widest animate-pulse">
        LOADING SAFETY DATA...
      </div>
    );
  }

  const score = data?.safetyScore ?? 0;
  const grade = data?.safetyGrade ?? "Moderate";
  const gradeColor = grade === "Safe" ? "text-emerald-400" : grade === "Moderate" ? "text-amber-400" : "text-red-400";
  const gradeBarColor = grade === "Safe" ? "bg-emerald-500" : grade === "Moderate" ? "bg-amber-500" : "bg-red-500";

  const fmt = (n: number) => n >= 100000 ? `${(n / 100000).toFixed(1)}L` : n >= 1000 ? `${(n / 1000).toFixed(1)}K` : `${n}`;
  const fmtRs = (n: number) => n >= 10000000 ? `Rs ${(n / 10000000).toFixed(1)} Cr` : n >= 100000 ? `Rs ${(n / 100000).toFixed(1)}L` : `Rs ${n.toLocaleString()}`;

  const crimeColors = ["#06b6d4", "#f59e0b", "#ef4444", "#8b5cf6", "#22c55e", "#f97316", "#64748b", "#a855f7"];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-mono font-bold uppercase tracking-widest text-foreground">
          Police & Safety
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Station directory, crime statistics, traffic data, and district safety score for Guntur.
        </p>
      </div>

      {/* Safety score + summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Safety score card */}
        <Card className="bg-card border-border/50">
          <CardContent className="p-5 text-center">
            <Shield className={`w-10 h-10 mx-auto mb-2 ${gradeColor}`} />
            <p className={`text-5xl font-bold font-mono ${gradeColor}`}>{score}</p>
            <p className="text-lg font-mono text-foreground mt-1">/100</p>
            <p className={`text-sm font-mono uppercase tracking-widest mt-1 ${gradeColor}`}>{grade}</p>
            <div className="mt-3 h-2 bg-background rounded-full overflow-hidden border border-border/50">
              <div className={`h-full transition-all duration-700 ${gradeBarColor}`} style={{ width: `${score}%` }} />
            </div>
          </CardContent>
        </Card>

        {/* Crime overview */}
        <Card className="bg-card border-border/50">
          <CardContent className="p-5">
            <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mb-3">Crime This Month</p>
            <p className="text-4xl font-bold font-mono text-foreground">{(data?.crimeStats?.totalThisMonth ?? 0).toLocaleString()}</p>
            <p className="text-xs text-muted-foreground mt-1">total cases registered</p>
            <div className="flex items-center gap-1 mt-2">
              {(data?.crimeStats?.totalThisMonth ?? 0) < (data?.crimeStats?.totalLastMonth ?? 0) ? (
                <>
                  <TrendingDown className="w-4 h-4 text-emerald-400" />
                  <span className="text-sm text-emerald-400 font-mono">
                    {Math.abs((data?.crimeStats?.totalThisMonth ?? 0) - (data?.crimeStats?.totalLastMonth ?? 0))} fewer than last month
                  </span>
                </>
              ) : (
                <>
                  <TrendingUp className="w-4 h-4 text-red-400" />
                  <span className="text-sm text-red-400 font-mono">
                    {(data?.crimeStats?.totalThisMonth ?? 0) - (data?.crimeStats?.totalLastMonth ?? 0)} more than last month
                  </span>
                </>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Traffic data */}
        <Card className="bg-card border-border/50">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 mb-3">
              <Car className="w-4 h-4 text-primary" />
              <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Traffic This Month</p>
            </div>
            <div className="space-y-3">
              <div>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Violations</p>
                <p className="text-2xl font-bold font-mono text-amber-400">
                  {(data?.trafficData?.violationsThisMonth ?? 0).toLocaleString()}
                </p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Revenue Collected</p>
                <p className="text-lg font-bold font-mono text-emerald-400">
                  {fmtRs(data?.trafficData?.revenueCollected ?? 0)}
                </p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Top Violation</p>
                <p className="text-sm font-mono text-foreground">{data?.trafficData?.majorViolation ?? "--"}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Crime category chart */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest">Crime Category Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={data?.crimeStats?.categories ?? []}
                margin={{ top: 5, right: 10, left: 0, bottom: 20 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
                <XAxis
                  dataKey="category"
                  tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                  angle={-25}
                  textAnchor="end"
                  height={50}
                />
                <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                <Tooltip
                  contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }}
                  formatter={(v: number, _: string, p) => [
                    `${v} cases`,
                    `${(p.payload as any).change >= 0 ? "+" : ""}${(p.payload as any).change}% vs last month`,
                  ]}
                />
                <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                  {(data?.crimeStats?.categories ?? []).map((_, i) => (
                    <Cell key={i} fill={crimeColors[i % crimeColors.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Compact category list */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-2">
            {(data?.crimeStats?.categories ?? []).map((cat, i) => (
              <div key={cat.category} className="flex items-center gap-2 text-xs">
                <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: crimeColors[i % crimeColors.length] }} />
                <span className="text-muted-foreground truncate">{cat.category}</span>
                <span className="font-mono text-foreground ml-auto">{cat.count}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Police station directory */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest flex items-center gap-2">
            <Shield className="w-4 h-4 text-primary" />
            Station Directory ({data?.stations?.length ?? 0} Stations)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {(data?.stations ?? []).map((station) => (
              <div key={station.id} className="bg-background/50 rounded-lg border border-border/40 p-4">
                <p className="font-semibold text-sm mb-1">{station.name}</p>
                <p className="text-[11px] text-muted-foreground mb-2 italic">{station.jurisdiction}</p>
                <div className="space-y-1 text-xs text-muted-foreground">
                  <p className="flex items-start gap-1.5">
                    <MapPin className="w-3 h-3 mt-0.5 shrink-0" />
                    {station.address}
                  </p>
                  <p className="flex items-center gap-1.5">
                    <Phone className="w-3 h-3 shrink-0" />
                    {station.phone}
                  </p>
                </div>
                <div className="flex items-center gap-3 mt-3">
                  <a
                    href={`tel:${station.phone}`}
                    className="text-[11px] font-mono text-primary hover:text-primary/80 transition-colors flex items-center gap-1"
                  >
                    <Phone className="w-3 h-3" /> Call
                  </a>
                  <button
                    onClick={() => station.mapUrl && openUrl(station.mapUrl)}
                    className="text-[11px] font-mono text-primary hover:text-primary/80 transition-colors flex items-center gap-1"
                  >
                    <MapPin className="w-3 h-3" /> Map
                  </button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <DataSource
        lastUpdated={data?.lastUpdated}
        sources={[
          { name: "AP Police (appolice.gov.in)", url: "https://appolice.gov.in", note: "Station directory" },
          { name: "NCRB Crime Statistics", url: "https://ncrb.gov.in", note: "Crime category benchmarks" },
          { name: "Guntur SP Office", note: "Monthly crime & traffic data" },
          { name: "AP Traffic Police", url: "https://appolice.gov.in", note: "Traffic violations & revenue" },
        ]}
      />
    </div>
  );
}
