import { useGetEconomy, getGetEconomyQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DataSource } from "@/components/data-source";
import { TrendingUp, TrendingDown, IndianRupee, Factory, Wallet, AlertTriangle } from "lucide-react";
import { useDistrict } from "@/contexts/district-context";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  AreaChart,
  Area,
} from "recharts";

const COLORS = ["#06b6d4", "#22d3ee", "#67e8f9", "#a5f3fc", "#0ea5e9", "#38bdf8", "#7dd3fc"];

export default function Economy() {
  const { district } = useDistrict();
  const params = { district };
  const { data, isLoading } = useGetEconomy(params, { query: { queryKey: getGetEconomyQueryKey(params) } });

  if (isLoading || !data) {
    return (
      <div className="flex items-center justify-center h-64 text-muted-foreground font-mono text-sm tracking-widest animate-pulse">
        LOADING ECONOMY DATA...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* KPI grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              <IndianRupee className="w-3.5 h-3.5" /> District GDP
            </div>
            <p className="text-2xl font-bold text-cyan-300 font-mono">₹{(data.gdpCrore / 1000).toFixed(1)}<span className="text-sm">K Cr</span></p>
            <p className="text-[11px] text-emerald-300 mt-1 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" /> {data.gdpGrowth}% growth
            </p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              <Wallet className="w-3.5 h-3.5" /> Per-capita Income
            </div>
            <p className="text-2xl font-bold text-fuchsia-300 font-mono">₹{(data.perCapitaIncome / 1000).toFixed(0)}<span className="text-sm">K</span></p>
            <p className="text-[11px] text-muted-foreground mt-1">per resident / year</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              <AlertTriangle className="w-3.5 h-3.5" /> Fiscal Deficit
            </div>
            <p className="text-2xl font-bold text-amber-300 font-mono">₹{data.fiscalDeficitCrore.toLocaleString("en-IN")} <span className="text-sm">Cr</span></p>
            <p className="text-[11px] text-muted-foreground mt-1">Exp − Rev (annual)</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              <TrendingDown className="w-3.5 h-3.5" /> Public Debt
            </div>
            <p className="text-2xl font-bold text-red-300 font-mono">₹{(data.debtCrore / 1000).toFixed(1)}<span className="text-sm">K Cr</span></p>
            <p className="text-[11px] text-muted-foreground mt-1">{data.debtToGdp}% of GDP</p>
          </CardContent>
        </Card>
      </div>

      {/* Revenue vs Expenditure */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest">Revenue vs Expenditure — 12-Month Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data.revenueExpenditureTrend} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} unit=" Cr" />
                <Tooltip
                  contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }}
                  formatter={(v: number) => [`₹${v} Cr`, ""]}
                />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Line type="monotone" dataKey="revenue" name="Revenue" stroke="#10b981" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="expenditure" name="Expenditure" stroke="#ef4444" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Debt + Revenue sources */}
      <div className="grid md:grid-cols-2 gap-4">
        <Card className="bg-card border-border/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-mono uppercase tracking-widest">Public Debt — 8-Year Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data.debtTrend} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                  <defs>
                    <linearGradient id="debtGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
                  <XAxis dataKey="year" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                  <YAxis
                    tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                    tickFormatter={(v) => `${(v / 1000).toFixed(0)}K`}
                  />
                  <Tooltip
                    contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }}
                    formatter={(v: number) => [`₹${v.toLocaleString("en-IN")} Cr`, "Debt"]}
                  />
                  <Area type="monotone" dataKey="debt" stroke="#ef4444" fill="url(#debtGrad)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-mono uppercase tracking-widest">Revenue Sources</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={data.revenueSources}
                    dataKey="amount"
                    nameKey="source"
                    cx="50%"
                    cy="50%"
                    innerRadius={42}
                    outerRadius={78}
                    paddingAngle={2}
                  >
                    {data.revenueSources.map((_, i) => (
                      <Cell key={i} fill={COLORS[i % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }}
                    formatter={(v: number) => [`₹${v} Cr`, ""]}
                  />
                  <Legend wrapperStyle={{ fontSize: 10 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Traffic revenue */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest">Traffic Revenue</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="rounded-lg bg-background/50 border border-border/40 p-4">
              <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Monthly</p>
              <p className="text-xl font-bold text-cyan-300 font-mono mt-1">₹{data.trafficRevenue.monthlyCrore} Cr</p>
            </div>
            <div className="rounded-lg bg-background/50 border border-border/40 p-4">
              <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Yearly (proj.)</p>
              <p className="text-xl font-bold text-emerald-300 font-mono mt-1">₹{data.trafficRevenue.yearlyCrore} Cr</p>
            </div>
            <div className="rounded-lg bg-background/50 border border-border/40 p-4">
              <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Violations / mo</p>
              <p className="text-xl font-bold text-amber-300 font-mono mt-1">{data.trafficRevenue.violations.toLocaleString("en-IN")}</p>
            </div>
            <div className="rounded-lg bg-background/50 border border-border/40 p-4">
              <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Collection Rate</p>
              <p className="text-xl font-bold text-fuchsia-300 font-mono mt-1">{data.trafficRevenue.collectionRate}%</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Industries */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest flex items-center gap-2">
            <Factory className="w-4 h-4 text-primary" /> Local Industries
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.industries} layout="vertical" margin={{ left: 8, right: 16 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} unit=" Cr" />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} width={170} />
                <Tooltip
                  contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }}
                  formatter={(v: number, n: string) => [n === "revenueCrore" ? `₹${v} Cr` : v.toLocaleString("en-IN"), n]}
                />
                <Bar dataKey="revenueCrore" name="Revenue (Cr)" fill="#06b6d4" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 grid sm:grid-cols-2 lg:grid-cols-4 gap-2">
            {data.industries.map((ind) => (
              <div key={ind.name} className="rounded-lg bg-background/40 border border-border/40 p-3">
                <p className="text-xs font-semibold text-foreground truncate">{ind.name}</p>
                <p className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest mt-1">{ind.sector}</p>
                <div className="flex justify-between text-[11px] font-mono mt-2">
                  <span className="text-cyan-300">{ind.units} units</span>
                  <span className="text-emerald-300">{(ind.employees / 1e3).toFixed(1)}K jobs</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <DataSource
        lastUpdated={data.lastUpdated}
        sources={[
          { name: "AP Finance Department", url: "https://apfinance.gov.in", note: "Revenue & expenditure" },
          { name: "AP Bureau of Economics & Statistics", url: "https://core.ap.gov.in", note: "GDP / GSDP" },
          { name: "MSME Development Institute (Guntur)", url: "https://msme.gov.in", note: "Industry data" },
          { name: "AP Transport Department", url: "https://aptransport.org", note: "Traffic revenue" },
        ]}
      />
    </div>
  );
}
