import { useGetMandals, getGetMandalsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Users, Maximize } from "lucide-react";
import { useDistrict } from "@/contexts/district-context";

export default function Mandals() {
  const { district } = useDistrict();
  const params = { district };
  const { data: mandals } = useGetMandals(params, { query: { queryKey: getGetMandalsQueryKey(params) } });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground font-mono uppercase tracking-tight">Mandal Database</h1>
          <p className="text-muted-foreground mt-1">Directory of all administrative divisions in the district.</p>
        </div>
        <div className="px-3 py-1 bg-primary/10 border border-primary/20 text-primary font-mono text-sm rounded">
          TOTAL: {mandals?.length || 0}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {mandals?.map((mandal) => (
          <Card key={mandal.id} className="border-border bg-card hover:border-primary/50 transition-colors">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg font-bold">{mandal.name}</CardTitle>
                <Badge variant="outline" className="font-mono text-xs uppercase bg-sidebar">
                  {mandal.type}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-2 mb-4">
                <div className="bg-sidebar p-2 rounded flex items-center gap-2 border border-border">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <div className="text-[10px] text-muted-foreground font-mono uppercase">Population</div>
                    <div className="text-sm font-bold font-mono">{(mandal.population / 1000).toFixed(1)}k</div>
                  </div>
                </div>
                <div className="bg-sidebar p-2 rounded flex items-center gap-2 border border-border">
                  <Maximize className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <div className="text-[10px] text-muted-foreground font-mono uppercase">Area</div>
                    <div className="text-sm font-bold font-mono">{mandal.area} km²</div>
                  </div>
                </div>
              </div>
              <div className="flex flex-wrap gap-1.5 mt-3">
                {mandal.tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="text-[10px] uppercase font-mono bg-accent text-accent-foreground">
                    {tag}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
