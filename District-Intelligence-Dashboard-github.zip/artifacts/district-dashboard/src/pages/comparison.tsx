import { useGetComparison, getGetComparisonQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DataSource } from "@/components/data-source";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Trophy, Map as MapIcon, Globe, Award } from "lucide-react";
import {
  BarChart,
  Bar,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Legend,
} from "recharts";
import { useDistrict } from "@/contexts/district-context";

export default function Comparison() {
  const { district } = useDistrict();
  const params = { district };
  const { data, isLoading } = useGetComparison(params, { query: { queryKey: getGetComparisonQueryKey(params) } });

  if (isLoading || !data) {
    return (
      <div className="flex items-center justify-center h-64 text-muted-foreground font-mono text-sm tracking-widest animate-pulse">
        LOADING COMPARISON DATA...
      </div>
    );
  }

  // Normalise for radar chart (0-100 scale)
  const radarData = data.metrics.map((m) => ({
    metric: m.metric,
    Guntur: Math.round(((m.guntur - m.worst) / (m.best - m.worst)) * 100) || 0,
    "State Avg": Math.round(((m.stateAvg - m.worst) / (m.best - m.worst)) * 100) || 0,
  }));

  return (
    <div className="space-y-6">
      {/* Hero */}
      <Card className="bg-card border-border/50 overflow-hidden">
        <CardContent className="p-6">
          <div className="flex flex-wrap items-center gap-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center">
                <Trophy className="w-8 h-8 text-primary" />
              </div>
              <div>
                <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">District Rank</p>
                <p className="text-3xl font-bold text-primary font-mono">#{data.currentRank}<span className="text-base text-muted-foreground"> / {data.totalDistricts}</span></p>
                <p className="text-xs text-muted-foreground mt-1">Composite Score Index — Andhra Pradesh</p>
              </div>
            </div>
            <div className="hidden md:block w-px h-16 bg-border" />
            <div className="flex items-center gap-4">
              <Globe className="w-8 h-8 text-cyan-300" />
              <div>
                <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">State</p>
                <p className="text-lg font-semibold text-cyan-200">{data.stateLevel.stateName}</p>
                <p className="text-xs text-muted-foreground mt-1">{data.stateLevel.totalDistricts} districts · ₹{(data.stateLevel.stateGdpCrore / 1e5).toFixed(2)}L Cr GSDP</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* State KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">State Population</p>
            <p className="text-2xl font-bold text-cyan-300 font-mono mt-1">{(data.stateLevel.totalPopulation / 1e7).toFixed(2)}<span className="text-sm">Cr</span></p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">State GSDP</p>
            <p className="text-2xl font-bold text-fuchsia-300 font-mono mt-1">₹{(data.stateLevel.stateGdpCrore / 1e5).toFixed(2)}<span className="text-sm">L Cr</span></p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Avg Literacy</p>
            <p className="text-2xl font-bold text-emerald-300 font-mono mt-1">{data.stateLevel.avgLiteracy}%</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Avg Sex Ratio</p>
            <p className="text-2xl font-bold text-amber-300 font-mono mt-1">{data.stateLevel.avgSexRatio}</p>
          </CardContent>
        </Card>
      </div>

      {/* Radar */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest">Guntur vs State Average</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData} outerRadius={100}>
                <PolarGrid stroke="hsl(var(--border))" />
                <PolarAngleAxis dataKey="metric" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                <PolarRadiusAxis tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
                <Radar name="Guntur" dataKey="Guntur" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.35} />
                <Radar name="State Avg" dataKey="State Avg" stroke="#a855f7" fill="#a855f7" fillOpacity={0.2} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Tooltip
                  contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Bar comparison */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest">All AP Districts — GDP Comparison</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.rankings} margin={{ top: 5, right: 10, left: 0, bottom: 50 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
                <XAxis dataKey="district" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} angle={-30} textAnchor="end" height={60} />
                <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}K`} />
                <Tooltip
                  contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }}
                  formatter={(v: number) => [`₹${v.toLocaleString("en-IN")} Cr`, "GDP"]}
                />
                <Bar dataKey="gdpCrore" radius={[4, 4, 0, 0]}>
                  {data.rankings.map((d) => (
                    <Cell key={d.district} fill={d.district === data.currentDistrict ? "#06b6d4" : "#1e3a5f"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Ranking Table */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest flex items-center gap-2">
            <Award className="w-4 h-4 text-primary" /> District Ranking — Composite Score
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-border/50">
                  <TableHead className="text-[10px] font-mono uppercase tracking-widest">Rank</TableHead>
                  <TableHead className="text-[10px] font-mono uppercase tracking-widest">District</TableHead>
                  <TableHead className="text-right text-[10px] font-mono uppercase tracking-widest">Score</TableHead>
                  <TableHead className="text-right text-[10px] font-mono uppercase tracking-widest">Population</TableHead>
                  <TableHead className="text-right text-[10px] font-mono uppercase tracking-widest">Literacy %</TableHead>
                  <TableHead className="text-right text-[10px] font-mono uppercase tracking-widest">GDP (Cr)</TableHead>
                  <TableHead className="text-right text-[10px] font-mono uppercase tracking-widest">Sex Ratio</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.rankings.map((d) => {
                  const isCurrent = d.district === data.currentDistrict;
                  return (
                    <TableRow
                      key={d.district}
                      className={`border-border/40 ${isCurrent ? "bg-primary/5" : ""}`}
                    >
                      <TableCell className="font-mono">
                        {d.rank <= 3 ? (
                          <Badge variant="outline" className="border-amber-400/40 text-amber-300 font-mono">#{d.rank}</Badge>
                        ) : (
                          <span className="text-muted-foreground">#{d.rank}</span>
                        )}
                      </TableCell>
                      <TableCell className={isCurrent ? "font-semibold text-primary" : "font-medium"}>
                        <div className="flex items-center gap-2">
                          <MapIcon className="w-3 h-3 text-muted-foreground/60" />
                          {d.district}
                          {isCurrent && <Badge variant="outline" className="text-[9px] font-mono">YOU</Badge>}
                        </div>
                      </TableCell>
                      <TableCell className="text-right font-mono text-cyan-300">{d.score}</TableCell>
                      <TableCell className="text-right font-mono text-muted-foreground">{(d.population / 1e6).toFixed(2)}M</TableCell>
                      <TableCell className="text-right font-mono text-emerald-300">{d.literacy}%</TableCell>
                      <TableCell className="text-right font-mono text-fuchsia-300">{d.gdpCrore.toLocaleString("en-IN")}</TableCell>
                      <TableCell className="text-right font-mono text-amber-300">{d.sexRatio}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <DataSource
        lastUpdated={data.lastUpdated}
        sources={[
          { name: "AP Bureau of Economics & Statistics", url: "https://core.ap.gov.in", note: "GSDP & district data" },
          { name: "Census of India", url: "https://censusindia.gov.in", note: "Population & demographics" },
          { name: "NITI Aayog – District Rankings", url: "https://niti.gov.in", note: "Composite indicators" },
        ]}
      />
    </div>
  );
}
