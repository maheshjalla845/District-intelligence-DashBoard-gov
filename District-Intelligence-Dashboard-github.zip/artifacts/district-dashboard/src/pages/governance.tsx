import { useGetGovernance, getGetGovernanceQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Building2, Shield, Stethoscope, GraduationCap, Landmark, FileCheck, FileWarning } from "lucide-react";
import { useDistrict } from "@/contexts/district-context";

export default function Governance() {
  const { district } = useDistrict();
  const params = { district };
  const { data: governance } = useGetGovernance(params, { query: { queryKey: getGetGovernanceQueryKey(params) } });

  const formatCurrency = (val: number) => `₹${(val / 10000000).toFixed(2)}Cr`;

  const budgetData = [
    { name: "Total Budget", value: governance?.totalBudget || 0 },
    { name: "Spent", value: governance?.spending || 0 },
    { name: "Revenue", value: governance?.revenue || 0 },
  ];

  const grievanceData = [
    { name: "Resolved", value: governance?.resolvedGrievances || 0, color: "hsl(var(--primary))" },
    { name: "Pending", value: governance?.pendingGrievances || 0, color: "hsl(var(--destructive))" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between md:items-end gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground font-mono uppercase tracking-tight">Governance & Finance</h1>
          <p className="text-muted-foreground mt-1">Detailed breakdown of district administration, budget, and infrastructure.</p>
        </div>
        {governance && (
          <div className="text-xs font-mono text-muted-foreground bg-sidebar px-3 py-2 rounded border border-border inline-flex items-center gap-2">
            LAST UPDATED: {new Date(governance.lastUpdated).toLocaleString()}
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 bg-primary/10 rounded-full text-primary">
              <Shield className="h-6 w-6" />
            </div>
            <div>
              <div className="text-2xl font-bold font-mono">{governance?.policeStations}</div>
              <div className="text-xs text-muted-foreground font-mono uppercase">Police Stations</div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 bg-primary/10 rounded-full text-primary">
              <Stethoscope className="h-6 w-6" />
            </div>
            <div>
              <div className="text-2xl font-bold font-mono">{governance?.hospitals}</div>
              <div className="text-xs text-muted-foreground font-mono uppercase">Hospitals/PHCs</div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 bg-primary/10 rounded-full text-primary">
              <GraduationCap className="h-6 w-6" />
            </div>
            <div>
              <div className="text-2xl font-bold font-mono">{governance?.schools}</div>
              <div className="text-xs text-muted-foreground font-mono uppercase">Schools</div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 bg-primary/10 rounded-full text-primary">
              <Building2 className="h-6 w-6" />
            </div>
            <div>
              <div className="text-2xl font-bold font-mono">{governance?.panchayats}</div>
              <div className="text-xs text-muted-foreground font-mono uppercase">Panchayats</div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-sm font-mono text-muted-foreground uppercase tracking-wider">Financial Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={budgetData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" tick={{ fontFamily: 'monospace', fontSize: 12 }} />
                  <YAxis tickFormatter={formatCurrency} stroke="hsl(var(--muted-foreground))" tick={{ fontFamily: 'monospace', fontSize: 12 }} />
                  <RechartsTooltip 
                    formatter={(value: number) => formatCurrency(value)}
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))' }}
                  />
                  <Bar dataKey="value" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-sm font-mono text-muted-foreground uppercase tracking-wider">Public Grievances</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center">
            <div className="h-48 w-full relative flex justify-center">
               <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={grievanceData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {grievanceData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <RechartsTooltip 
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))' }}
                    />
                  </PieChart>
               </ResponsiveContainer>
               <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                  <div className="text-3xl font-bold font-mono text-foreground">
                    {((governance?.resolvedGrievances || 0) / ((governance?.resolvedGrievances || 1) + (governance?.pendingGrievances || 0)) * 100).toFixed(0)}%
                  </div>
                  <div className="text-[10px] font-mono text-muted-foreground uppercase">Resolution Rate</div>
               </div>
            </div>
            
            <div className="flex gap-8 mt-6">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-primary" />
                <div className="font-mono text-sm"><span className="text-muted-foreground mr-1">Resolved:</span> {governance?.resolvedGrievances}</div>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-destructive" />
                <div className="font-mono text-sm"><span className="text-muted-foreground mr-1">Pending:</span> {governance?.pendingGrievances}</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
