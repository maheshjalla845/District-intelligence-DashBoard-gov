import {
  useGetDistrict,
  useGetDistrictHealthScore,
  useGetWeather,
  useGetDamLevels,
  useGetAlerts,
  useGetMandiPrices,
  useGetNews,
  useGetGovernance,
  getGetDistrictQueryKey,
  getGetDistrictHealthScoreQueryKey,
  getGetWeatherQueryKey,
  getGetDamLevelsQueryKey,
  getGetAlertsQueryKey,
  getGetMandiPricesQueryKey,
  getGetNewsQueryKey,
  getGetGovernanceQueryKey,
  useHealthCheck,
  getHealthCheckQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from "recharts";
import { AlertTriangle, Cloud, Droplets, Wind, Sun, TrendingUp, TrendingDown, ArrowRight, Server } from "lucide-react";
import { Link } from "wouter";
import { useDistrict } from "@/contexts/district-context";

export default function Home() {
  const { district: selectedDistrict } = useDistrict();
  const params = { district: selectedDistrict };
  const { data: district } = useGetDistrict(params, { query: { queryKey: getGetDistrictQueryKey(params) } });
  const { data: healthScore } = useGetDistrictHealthScore(params, {
    query: { queryKey: getGetDistrictHealthScoreQueryKey(params) },
  });
  const { data: weather } = useGetWeather(params, { query: { queryKey: getGetWeatherQueryKey(params) } });
  const { data: damLevels } = useGetDamLevels(params, { query: { queryKey: getGetDamLevelsQueryKey(params) } });
  const { data: alerts } = useGetAlerts(params, { query: { queryKey: getGetAlertsQueryKey(params) } });
  const { data: mandiPrices } = useGetMandiPrices(params, { query: { queryKey: getGetMandiPricesQueryKey(params) } });
  const { data: news } = useGetNews(params, { query: { queryKey: getGetNewsQueryKey(params) } });
  const { data: governance } = useGetGovernance(params, { query: { queryKey: getGetGovernanceQueryKey(params) } });
  const { data: healthCheck } = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey() } });

  const healthData = healthScore
    ? Object.entries(healthScore.metrics).map(([key, value]) => ({
        subject: key.charAt(0).toUpperCase() + key.slice(1),
        A: value,
        fullMark: 100,
      }))
    : [];

  return (
    <div className="space-y-6">
      {/* Top Banner Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="md:col-span-3 bg-sidebar border-sidebar-border">
          <CardContent className="p-6 flex flex-col justify-center h-full">
            <h1 className="text-3xl font-bold text-foreground font-mono tracking-tight uppercase">
              {district?.name || "Loading..."}
            </h1>
            <p className="text-muted-foreground mt-1">{district?.tagline}</p>
            <div className="flex flex-wrap gap-2 mt-4">
              {district?.tags.map((tag) => (
                <Badge key={tag} variant="secondary" className="font-mono text-xs uppercase bg-primary/20 text-primary hover:bg-primary/30">
                  {tag}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border flex flex-col items-center justify-center p-6 text-center">
          <div className="text-sm font-mono text-muted-foreground mb-2">SYSTEM STATUS</div>
          <div className="flex items-center gap-2">
            <Server className={`h-6 w-6 ${healthCheck?.status === 'ok' ? 'text-green-500' : 'text-red-500'}`} />
            <span className="text-xl font-bold font-mono uppercase">{healthCheck?.status || 'UNKNOWN'}</span>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* District Health Score */}
        <Card className="md:col-span-1 border-border bg-card">
          <CardHeader>
            <CardTitle className="text-sm font-mono text-muted-foreground uppercase tracking-wider">Health Index</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center">
            <div className="relative w-48 h-48 flex items-center justify-center mb-4">
              <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
                <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="8" className="text-muted/20" />
                <circle
                  cx="50"
                  cy="50"
                  r="45"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="8"
                  strokeDasharray={`${(healthScore?.overall || 0) * 2.827} 282.7`}
                  className="text-primary"
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute flex flex-col items-center justify-center">
                <span className="text-4xl font-bold font-mono text-primary">{healthScore?.overall}</span>
                <span className="text-lg font-bold text-muted-foreground">Grade {healthScore?.grade}</span>
              </div>
            </div>
            
            <div className="w-full h-[250px] mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="70%" data={healthData}>
                  <PolarGrid stroke="hsl(var(--border))" />
                  <PolarAngleAxis dataKey="subject" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 10, fontFamily: "monospace" }} />
                  <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                  <Radar name="Score" dataKey="A" stroke="hsl(var(--primary))" fill="hsl(var(--primary))" fillOpacity={0.3} />
                  <Tooltip
                    contentStyle={{ backgroundColor: "hsl(var(--card))", borderColor: "hsl(var(--border))", color: "hsl(var(--foreground))" }}
                    itemStyle={{ color: "hsl(var(--primary))" }}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Alerts & Weather */}
        <div className="md:col-span-1 space-y-6">
          <Card className="border-border bg-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-mono text-muted-foreground uppercase tracking-wider flex items-center justify-between">
                Active Alerts
                {alerts && alerts.length > 0 && (
                  <Badge variant="destructive" className="bg-destructive text-destructive-foreground animate-pulse">
                    {alerts.length} ALERTS
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {alerts?.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground font-mono text-sm">NO ACTIVE ALERTS</div>
              ) : (
                <div className="space-y-3">
                  {alerts?.slice(0, 4).map((alert) => {
                    const colorMap = {
                      critical: "bg-red-500/10 border-red-500/20 text-red-500",
                      warning: "bg-orange-500/10 border-orange-500/20 text-orange-500",
                      medium: "bg-yellow-500/10 border-yellow-500/20 text-yellow-500",
                      info: "bg-blue-500/10 border-blue-500/20 text-blue-500",
                    };
                    return (
                      <div key={alert.id} className={`p-3 rounded border ${colorMap[alert.severity]} flex items-start gap-3`}>
                        <AlertTriangle className="h-5 w-5 shrink-0 mt-0.5" />
                        <div>
                          <div className="font-bold text-sm uppercase tracking-wide">{alert.title}</div>
                          <div className="text-xs opacity-90 mt-1">{alert.description}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-mono text-muted-foreground uppercase tracking-wider">Live Weather</CardTitle>
            </CardHeader>
            <CardContent>
              {weather && (
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-4xl font-bold font-mono text-foreground">{weather.temperature}°C</div>
                    <div className="text-sm text-muted-foreground uppercase mt-1">{weather.condition}</div>
                  </div>
                  <div className="space-y-2 text-right">
                    <div className="flex items-center justify-end gap-2 text-sm text-muted-foreground">
                      <span>Humidity {weather.humidity}%</span>
                      <Droplets className="h-4 w-4 text-blue-400" />
                    </div>
                    <div className="flex items-center justify-end gap-2 text-sm text-muted-foreground">
                      <span>Wind {weather.windSpeed}km/h</span>
                      <Wind className="h-4 w-4 text-gray-400" />
                    </div>
                    <div className="flex items-center justify-end gap-2 text-sm text-muted-foreground">
                      <span>UV Index {weather.uvIndex}</span>
                      <Sun className="h-4 w-4 text-yellow-400" />
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Resources & Governance Snippet */}
        <div className="md:col-span-1 space-y-6">
          <Card className="border-border bg-card">
            <CardHeader className="pb-2 flex flex-row items-center justify-between">
              <CardTitle className="text-sm font-mono text-muted-foreground uppercase tracking-wider">Mandi Prices (Top)</CardTitle>
              <Link href="/mandi" className="text-xs text-primary hover:underline font-mono">VIEW ALL</Link>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mandiPrices?.slice(0, 4).map((item) => (
                  <div key={item.id} className="flex items-center justify-between border-b border-border/50 pb-2 last:border-0 last:pb-0">
                    <div>
                      <div className="font-semibold text-sm">{item.crop}</div>
                      <div className="text-xs text-muted-foreground">{item.variety}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono text-sm">₹{item.price}/{item.unit}</div>
                      <div className={`text-xs flex items-center justify-end gap-1 font-mono ${item.change >= 0 ? "text-green-500" : "text-red-500"}`}>
                        {item.change >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                        {Math.abs(item.changePercent)}%
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardHeader className="pb-2 flex flex-row items-center justify-between">
              <CardTitle className="text-sm font-mono text-muted-foreground uppercase tracking-wider">Dam Levels</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {damLevels?.map((dam) => (
                  <div key={dam.id} className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="font-medium">{dam.name}</span>
                      <span className="font-mono text-muted-foreground">{dam.percentFilled}%</span>
                    </div>
                    <Progress value={dam.percentFilled} className="h-2" />
                    <div className="text-xs text-muted-foreground text-right">{dam.currentLevel} / {dam.capacity} TMC</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
         {/* Governance Overview */}
         <Card className="border-border bg-card">
          <CardHeader className="pb-2 flex flex-row items-center justify-between">
            <CardTitle className="text-sm font-mono text-muted-foreground uppercase tracking-wider">Governance Stats</CardTitle>
            <Link href="/governance" className="text-xs text-primary hover:underline font-mono">DETAILS</Link>
          </CardHeader>
          <CardContent>
            {governance && (
               <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-sidebar rounded border border-border flex flex-col justify-center">
                    <div className="text-xs text-muted-foreground font-mono mb-1 uppercase">Budget Utilized</div>
                    <div className="text-2xl font-bold font-mono text-primary">{governance.utilizationPercent}%</div>
                  </div>
                  <div className="p-4 bg-sidebar rounded border border-border flex flex-col justify-center">
                    <div className="text-xs text-muted-foreground font-mono mb-1 uppercase">Active Schemes</div>
                    <div className="text-2xl font-bold font-mono text-primary">{governance.activeSchemes}</div>
                  </div>
                  <div className="p-4 bg-sidebar rounded border border-border flex flex-col justify-center">
                    <div className="text-xs text-muted-foreground font-mono mb-1 uppercase">Pending Grievances</div>
                    <div className="text-2xl font-bold font-mono text-orange-500">{governance.pendingGrievances}</div>
                  </div>
                  <div className="p-4 bg-sidebar rounded border border-border flex flex-col justify-center">
                    <div className="text-xs text-muted-foreground font-mono mb-1 uppercase">Resolved Grievances</div>
                    <div className="text-2xl font-bold font-mono text-green-500">{governance.resolvedGrievances}</div>
                  </div>
               </div>
            )}
          </CardContent>
        </Card>

         {/* News */}
         <Card className="border-border bg-card">
          <CardHeader className="pb-2 flex flex-row items-center justify-between">
            <CardTitle className="text-sm font-mono text-muted-foreground uppercase tracking-wider">Intelligence Feed</CardTitle>
            <Link href="/news" className="text-xs text-primary hover:underline font-mono">FULL FEED</Link>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {news?.slice(0, 3).map((item) => (
                <div key={item.id} className="group cursor-pointer">
                  <div className="flex items-center justify-between mb-1">
                    <Badge variant="outline" className="text-[10px] font-mono uppercase bg-accent/50 text-accent-foreground border-accent-foreground/20">{item.category}</Badge>
                    <span className="text-xs text-muted-foreground font-mono">{new Date(item.publishedAt).toLocaleDateString()}</span>
                  </div>
                  <h3 className="text-sm font-semibold group-hover:text-primary transition-colors line-clamp-2">{item.headline}</h3>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

    </div>
  );
}
