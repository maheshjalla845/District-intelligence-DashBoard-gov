import {
  useGetPowerStatus,
  getGetPowerStatusQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Zap, ZapOff, Clock, AlertTriangle, CheckCircle, Wrench } from "lucide-react";
import { DataSource } from "@/components/data-source";
import { useDistrict } from "@/contexts/district-context";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

const outageTypeBadge: Record<string, string> = {
  scheduled: "text-amber-400 bg-amber-500/10 border-amber-500/30",
  unscheduled: "text-red-400 bg-red-500/10 border-red-500/30",
};

const outageStatusBadge: Record<string, string> = {
  active: "text-red-400 bg-red-500/10 border-red-500/30",
  upcoming: "text-amber-400 bg-amber-500/10 border-amber-500/30",
  resolved: "text-emerald-400 bg-emerald-500/10 border-emerald-500/30",
};

export default function Power() {
  const { district } = useDistrict();
  const params = { district };
  const { data, isLoading } = useGetPowerStatus(params, {
    query: { queryKey: getGetPowerStatusQueryKey(params) },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64 text-muted-foreground font-mono text-sm tracking-widest animate-pulse">
        LOADING POWER DATA...
      </div>
    );
  }

  const isStable = data?.overallStatus === "stable";
  const isMajor = data?.overallStatus === "major_outage";

  const demandSupplyData = [
    { label: "Demand", value: data?.demand ?? 0, fill: "#f59e0b" },
    { label: "Supply", value: data?.supply ?? 0, fill: "#22d3ee" },
  ];

  const fmt = (n: number) => n >= 1000 ? `${(n / 1000).toFixed(1)}K` : `${n}`;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-mono font-bold uppercase tracking-widest text-foreground">
          Power & Outages
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Live power grid status, scheduled maintenance, and unscheduled outage alerts for Guntur District.
        </p>
      </div>

      {/* Live status banner */}
      <div
        className={`rounded-xl border p-5 flex items-center gap-4 ${
          isStable
            ? "bg-emerald-500/5 border-emerald-500/30"
            : isMajor
            ? "bg-red-500/5 border-red-500/30"
            : "bg-amber-500/5 border-amber-500/30"
        }`}
      >
        {isStable ? (
          <CheckCircle className="w-8 h-8 text-emerald-400 shrink-0" />
        ) : (
          <ZapOff className={`w-8 h-8 shrink-0 ${isMajor ? "text-red-400" : "text-amber-400"}`} />
        )}
        <div>
          <p className={`text-lg font-bold font-mono ${isStable ? "text-emerald-400" : isMajor ? "text-red-400" : "text-amber-400"}`}>
            {isStable ? "Grid Stable — All Areas Live" : isMajor ? "Major Grid Outage Detected" : "Partial Outages Active"}
          </p>
          <p className="text-sm text-muted-foreground">
            {(data?.activeOutages ?? 0)} active outage(s) affecting{" "}
            {fmt(data?.affectedHouseholds ?? 0)} households
          </p>
        </div>
        <div className="ml-auto text-right hidden md:block">
          <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Updated</p>
          <p className="text-xs font-mono text-foreground">
            {data?.lastUpdated ? new Date(data.lastUpdated).toLocaleTimeString() : "--"}
          </p>
        </div>
      </div>

      {/* Demand vs Supply */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-card border-border/50 md:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-mono uppercase tracking-widest flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400" />
              Demand vs Supply (MW)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-44">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={demandSupplyData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
                  <XAxis dataKey="label" tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))" }} />
                  <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                  <Tooltip
                    contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }}
                    formatter={(v: number) => [`${v} MW`, ""]}
                  />
                  <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                    {demandSupplyData.map((entry, index) => (
                      <Cell key={index} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-3">
          {[
            { label: "Demand", value: `${data?.demand ?? "--"} MW`, color: "text-amber-400" },
            { label: "Supply", value: `${data?.supply ?? "--"} MW`, color: "text-cyan-400" },
            { label: "Deficit", value: `${data?.deficit ?? 0} MW`, color: (data?.deficit ?? 0) > 0 ? "text-red-400" : "text-emerald-400" },
            { label: "Active Outages", value: data?.activeOutages ?? 0, color: (data?.activeOutages ?? 0) > 0 ? "text-red-400" : "text-emerald-400" },
          ].map((s) => (
            <Card key={s.label} className="bg-card border-border/50">
              <CardContent className="p-3 flex items-center justify-between">
                <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">{s.label}</p>
                <p className={`text-lg font-bold font-mono ${s.color}`}>{s.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Outage list */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest flex items-center gap-2">
            <Wrench className="w-4 h-4 text-primary" />
            Outage Schedule & Alerts
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {(data?.outages ?? []).map((outage) => (
              <div
                key={outage.id}
                className={`rounded-lg border p-4 ${
                  outage.status === "active"
                    ? "bg-red-500/5 border-red-500/20"
                    : outage.status === "upcoming"
                    ? "bg-amber-500/5 border-amber-500/20"
                    : "bg-background/50 border-border/40"
                }`}
              >
                <div className="flex flex-wrap items-start gap-2 mb-2">
                  <p className="font-semibold text-sm flex-1">{outage.area}</p>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${outageTypeBadge[outage.type]}`}>
                    {outage.type}
                  </span>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${outageStatusBadge[outage.status]}`}>
                    {outage.status}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground mb-2">{outage.reason}</p>
                <div className="flex flex-wrap gap-4 text-xs font-mono">
                  <span className="flex items-center gap-1 text-muted-foreground">
                    <Clock className="w-3 h-3" />
                    {outage.startTime} – {outage.endTime}
                  </span>
                  <span className="text-muted-foreground">
                    {outage.affectedHouseholds.toLocaleString()} households affected
                  </span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <DataSource
        lastUpdated={data?.lastUpdated}
        sources={[
          { name: "APSPDCL", url: "https://www.apspdcl.in", note: "Southern Power Distribution — Guntur zone" },
          { name: "APERC", url: "https://aperc.gov.in", note: "AP Electricity Regulatory Commission" },
          { name: "Ministry of Power", url: "https://powermin.gov.in", note: "Demand/supply benchmarks" },
        ]}
      />
    </div>
  );
}
