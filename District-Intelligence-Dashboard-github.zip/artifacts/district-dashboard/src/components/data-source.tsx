import { Info, ExternalLink } from "lucide-react";
import { openUrl } from "@/lib/open-url";

interface Source {
  name: string;
  url?: string;
  note?: string;
}

interface DataSourceProps {
  sources: Source[];
  lastUpdated?: string;
}

export function DataSource({ sources, lastUpdated }: DataSourceProps) {
  return (
    <div className="mt-6 rounded-lg border border-border/40 bg-muted/10 px-4 py-3">
      <div className="flex items-start gap-2">
        <Info className="w-3.5 h-3.5 text-muted-foreground/60 mt-0.5 shrink-0" />
        <div className="flex-1 min-w-0">
          <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground/60 mb-1.5">
            Data Sources
          </p>
          <div className="flex flex-wrap gap-x-4 gap-y-1">
            {sources.map((src) => (
              <span key={src.name} className="text-[11px] text-muted-foreground/70 flex items-center gap-1">
                {src.url ? (
                  <button
                    onClick={() => openUrl(src.url!)}
                    className="underline underline-offset-2 decoration-dashed hover:text-muted-foreground transition-colors flex items-center gap-0.5"
                  >
                    {src.name}
                    <ExternalLink className="w-2.5 h-2.5" />
                  </button>
                ) : (
                  <span>{src.name}</span>
                )}
                {src.note && <span className="text-muted-foreground/50">({src.note})</span>}
              </span>
            ))}
          </div>
          {lastUpdated && (
            <p className="text-[10px] font-mono text-muted-foreground/50 mt-1.5">
              Last updated: {new Date(lastUpdated).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", hour12: true })} IST
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
