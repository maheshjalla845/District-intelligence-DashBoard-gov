import { AppLayout } from "@/components/layout";
import {
  Redirect,
  Switch,
  Route,
  Router as WouterRouter,
  Link,
  useLocation,
} from "wouter";
import {
  ClerkProvider,
  SignIn,
  SignUp,
  useAuth,
  useClerk,
} from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { shadcn } from "@clerk/themes";
import { useEffect, useRef } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { DistrictProvider } from "@/contexts/district-context";
import NotFound from "@/pages/not-found";

import Home from "@/pages/home";
import Mandals from "@/pages/mandals";
import Services from "@/pages/services";
import Governance from "@/pages/governance";
import News from "@/pages/news";
import Mandi from "@/pages/mandi";
import Water from "@/pages/water";
import Housing from "@/pages/housing";
import Power from "@/pages/power";
import Health from "@/pages/health";
import Police from "@/pages/police";
import AQI from "@/pages/aqi";
import Demographics from "@/pages/demographics";
import Transparency from "@/pages/transparency";
import Infrastructure from "@/pages/infrastructure";
import Economy from "@/pages/economy";
import Comparison from "@/pages/comparison";
import Traffic from "@/pages/traffic";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: true,
      staleTime: 1000 * 60 * 2,
      refetchInterval: 1000 * 60 * 5,
    },
  },
});

const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

if (!clerkPubKey) {
  throw new Error("Missing VITE_CLERK_PUBLISHABLE_KEY in the environment.");
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
    socialButtonsPlacement: "top" as const,
    socialButtonsVariant: "blockButton" as const,
  },
  variables: {
    colorPrimary: "#18a8ad",
    colorForeground: "#e8f2f3",
    colorMutedForeground: "#91a5aa",
    colorDanger: "#ef6262",
    colorBackground: "#111b1f",
    colorInput: "#19272c",
    colorInputForeground: "#e8f2f3",
    colorNeutral: "#385057",
    fontFamily: "Inter, sans-serif",
    borderRadius: "0.5rem",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "bg-[#111b1f] rounded-2xl w-[440px] max-w-full overflow-hidden",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "!text-[#e8f2f3]",
    headerSubtitle: "!text-[#91a5aa]",
    socialButtonsBlockButtonText: "!text-[#e8f2f3]",
    formFieldLabel: "!text-[#e8f2f3]",
    footerActionLink: "!text-[#58d1d1]",
    footerActionText: "!text-[#91a5aa]",
    dividerText: "!text-[#91a5aa]",
    identityPreviewEditButton: "!text-[#58d1d1]",
    formFieldSuccessText: "!text-[#58d1d1]",
    alertText: "!text-[#ff9999]",
    logoBox: "mb-2",
    logoImage: "max-h-10",
    socialButtonsBlockButton: "!bg-[#19272c] !border-[#385057] hover:!bg-[#22343a]",
    formButtonPrimary: "!bg-[#18a8ad] hover:!bg-[#159295] !text-[#071013]",
    formFieldInput: "!bg-[#19272c] !border-[#385057] !text-[#e8f2f3]",
    footerAction: "!bg-transparent",
    dividerLine: "!bg-[#385057]",
    alert: "!bg-[#3a2225] !border-[#8c4148]",
    otpCodeFieldInput: "!bg-[#19272c] !border-[#385057] !text-[#e8f2f3]",
    formFieldRow: "mb-4",
    main: "gap-5",
  },
};

function LoadingScreen() {
  return (
    <div className="min-h-[100dvh] bg-background flex items-center justify-center text-muted-foreground font-mono text-sm uppercase tracking-wider">
      Loading secure session…
    </div>
  );
}

function PublicLanding() {
  return (
    <main className="min-h-[100dvh] bg-background text-foreground flex items-center justify-center px-6 py-12">
      <div className="w-full max-w-4xl grid gap-10 md:grid-cols-[1.2fr_0.8fr] items-center">
        <section>
          <p className="font-mono text-xs uppercase tracking-[0.28em] text-primary mb-5">
            District Intelligence
          </p>
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight leading-[1.05]">
            Guntur Ops
          </h1>
          <p className="mt-6 max-w-xl text-lg text-muted-foreground leading-relaxed">
            A secure operations dashboard for district services, infrastructure,
            governance, and public intelligence.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              href="/sign-in"
              className="inline-flex items-center justify-center rounded-md bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Sign in
            </Link>
            <Link
              href="/sign-up"
              className="inline-flex items-center justify-center rounded-md border border-border bg-card px-5 py-2.5 text-sm font-semibold transition-colors hover:bg-accent"
            >
              Create account
            </Link>
          </div>
        </section>
        <aside className="rounded-xl border border-border bg-card p-6 shadow-lg">
          <div className="flex items-center gap-2 font-mono text-xs uppercase tracking-wider text-primary">
            <span className="h-2 w-2 rounded-full bg-green-500" />
            Secure access
          </div>
          <p className="mt-5 text-sm text-muted-foreground leading-relaxed">
            Sign in to view live district data and operational indicators.
            Authentication is handled by Clerk with protected server-side API
            routes.
          </p>
        </aside>
      </div>
    </main>
  );
}

function HomeRedirect() {
  const { isLoaded, isSignedIn } = useAuth();

  if (!isLoaded) return <LoadingScreen />;
  if (isSignedIn) return <Redirect to="/dashboard" />;
  return <PublicLanding />;
}

function ProtectedApp() {
  const { isLoaded, isSignedIn } = useAuth();

  if (!isLoaded) return <LoadingScreen />;
  if (!isSignedIn) return <Redirect to="/" />;

  return (
    <AppLayout>
      <Switch>
        <Route path="/dashboard" component={Home} />
        <Route path="/mandals" component={Mandals} />
        <Route path="/services" component={Services} />
        <Route path="/governance" component={Governance} />
        <Route path="/news" component={News} />
        <Route path="/mandi" component={Mandi} />
        <Route path="/water" component={Water} />
        <Route path="/housing" component={Housing} />
        <Route path="/power" component={Power} />
        <Route path="/health" component={Health} />
        <Route path="/police" component={Police} />
        <Route path="/aqi" component={AQI} />
        <Route path="/demographics" component={Demographics} />
        <Route path="/transparency" component={Transparency} />
        <Route path="/infrastructure" component={Infrastructure} />
        <Route path="/economy" component={Economy} />
        <Route path="/comparison" component={Comparison} />
        <Route path="/traffic" component={Traffic} />
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

function SignInPage() {
  return (
    <div className="min-h-[100dvh] bg-background flex items-center justify-center px-4">
      <SignIn
        routing="path"
        path={`${basePath}/sign-in`}
        signUpUrl={`${basePath}/sign-up`}
      />
    </div>
  );
}

function SignUpPage() {
  return (
    <div className="min-h-[100dvh] bg-background flex items-center justify-center px-4">
      <SignUp
        routing="path"
        path={`${basePath}/sign-up`}
        signInUrl={`${basePath}/sign-in`}
      />
    </div>
  );
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const previousUserId = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (
        previousUserId.current !== undefined &&
        previousUserId.current !== userId
      ) {
        queryClient.clear();
      }
      previousUserId.current = userId;
    });
    return unsubscribe;
  }, [addListener]);

  return null;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomeRedirect} />
      <Route path="/sign-in/*?" component={SignInPage} />
      <Route path="/sign-up/*?" component={SignUpPage} />
      <Route component={ProtectedApp} />
    </Switch>
  );
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: {
          start: {
            title: "Welcome back",
            subtitle: "Sign in to access district intelligence",
          },
        },
        signUp: {
          start: {
            title: "Create your account",
            subtitle: "Get secure access to the dashboard",
          },
        },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <ClerkQueryClientCacheInvalidator />
      <Router />
    </ClerkProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <DistrictProvider>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <ClerkProviderWithRoutes />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </DistrictProvider>
    </QueryClientProvider>
  );
}

export default App;
