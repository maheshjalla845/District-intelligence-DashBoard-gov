import type { RequestHandler } from "express";
import { getAuth } from "@clerk/express";

/**
 * Protects application data routes with Clerk's browser session.
 *
 * The health endpoint is mounted before this middleware so monitoring can
 * remain public. Browser requests do not need bearer-token handling: Clerk's
 * session cookie is sent automatically for the same-origin API.
 */
export const requireAuth: RequestHandler = (req, res, next) => {
  const { userId } = getAuth(req);

  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  res.locals.userId = userId;
  next();
};