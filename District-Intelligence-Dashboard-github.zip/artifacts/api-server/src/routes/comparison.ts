import { Router } from "express";
import { cache } from "../lib/cache";
import { resolveDistrict } from "../lib/district";

const router = Router();

const districts = [
  { district: "Visakhapatnam", population: 4290000, literacy: 75.2, gdpCrore: 168400, sexRatio: 1006 },
  { district: "Guntur", population: 5823000, literacy: 67.4, gdpCrore: 138400, sexRatio: 1003 },
  { district: "Krishna", population: 4517000, literacy: 73.8, gdpCrore: 124200, sexRatio: 1009 },
  { district: "East Godavari", population: 5151000, literacy: 70.9, gdpCrore: 116200, sexRatio: 1006 },
  { district: "West Godavari", population: 3936000, literacy: 74.6, gdpCrore: 108800, sexRatio: 1004 },
  { district: "Chittoor", population: 4174000, literacy: 71.5, gdpCrore: 96400, sexRatio: 998 },
  { district: "Anantapur", population: 4083000, literacy: 63.6, gdpCrore: 78600, sexRatio: 977 },
  { district: "Kurnool", population: 4053000, literacy: 60.0, gdpCrore: 74200, sexRatio: 988 },
  { district: "Nellore", population: 2964000, literacy: 68.9, gdpCrore: 89400, sexRatio: 985 },
  { district: "Prakasam", population: 3392000, literacy: 63.1, gdpCrore: 68400, sexRatio: 986 },
  { district: "Kadapa", population: 2884000, literacy: 67.3, gdpCrore: 64200, sexRatio: 985 },
  { district: "Srikakulam", population: 2699000, literacy: 61.7, gdpCrore: 58400, sexRatio: 1015 },
  { district: "Vizianagaram", population: 2342000, literacy: 58.9, gdpCrore: 48200, sexRatio: 1019 },
];

router.get("/comparison", (req, res) => {
  const slug = resolveDistrict(req);
  const currentDistrictName = slug === "krishna" ? "Krishna" : "Guntur";
  const cacheKey = `comparison-${slug}`;
  const cached = cache.get<object>(cacheKey);
  if (cached) return res.json(cached);

  // Composite score: weight GDP, literacy, sex ratio
  const ranked = districts
    .map((d) => {
      const gdpNorm = (d.gdpCrore / 168400) * 40;
      const litNorm = (d.literacy / 80) * 35;
      const sexNorm = (d.sexRatio / 1020) * 25;
      const score = Math.round((gdpNorm + litNorm + sexNorm) * 10) / 10;
      return { ...d, score };
    })
    .sort((a, b) => b.score - a.score)
    .map((d, i) => ({ rank: i + 1, ...d }));

  const currentRank = ranked.find((d) => d.district === currentDistrictName)?.rank ?? 0;

  const totalPopulation = districts.reduce((s, d) => s + d.population, 0);
  const stateGdpCrore = districts.reduce((s, d) => s + d.gdpCrore, 0);
  const avgLiteracy = Math.round((districts.reduce((s, d) => s + d.literacy, 0) / districts.length) * 10) / 10;
  const avgSexRatio = Math.round(districts.reduce((s, d) => s + d.sexRatio, 0) / districts.length);

  const current = districts.find((d) => d.district === currentDistrictName)!;

  const metrics = [
    { metric: "Literacy %", guntur: current.literacy, stateAvg: avgLiteracy, best: 75.2, worst: 58.9 },
    { metric: "Sex Ratio", guntur: current.sexRatio, stateAvg: avgSexRatio, best: 1019, worst: 977 },
    { metric: "GDP (Crore)", guntur: current.gdpCrore, stateAvg: Math.round(stateGdpCrore / districts.length), best: 168400, worst: 48200 },
    { metric: "Population (M)", guntur: Math.round(current.population / 1e5) / 10, stateAvg: Math.round(totalPopulation / districts.length / 1e5) / 10, best: 5.8, worst: 2.3 },
  ];

  const data = {
    currentDistrict: currentDistrictName,
    rankings: ranked,
    currentRank,
    totalDistricts: districts.length,
    metrics,
    stateLevel: {
      stateName: "Andhra Pradesh",
      totalPopulation,
      totalDistricts: 26,
      stateGdpCrore: Math.round(stateGdpCrore * 1.1),
      avgLiteracy,
      avgSexRatio,
    },
    lastUpdated: new Date().toISOString(),
  };

  cache.set(cacheKey, data, 60 * 60 * 1000);
  return res.json(data);
});

export default router;
