import { Router } from "express";
import { cache } from "../lib/cache";
import { resolveDistrict } from "../lib/district";

const router = Router();

const GUNTUR_PROJECTS = [
  { id: "ip-001", name: "Outer Ring Road – Phase 2 (Guntur–Mangalagiri)", type: "road" as const, location: "Guntur Urban", status: "ongoing" as const, startDate: "2024-08-12", endDate: "2026-12-30", budgetCrore: 484, utilizedCrore: 348, progress: 72, contractor: "L&T Construction" },
  { id: "ip-002", name: "Krishna River Bridge Strengthening", type: "bridge" as const, location: "Prakasam Barrage", status: "ongoing" as const, startDate: "2025-03-04", endDate: "2026-09-30", budgetCrore: 162, utilizedCrore: 88, progress: 55, contractor: "NCC Limited" },
  { id: "ip-003", name: "District Collectorate Modernisation", type: "building" as const, location: "Nallapadu, Guntur", status: "completed" as const, startDate: "2023-06-12", endDate: "2026-02-15", budgetCrore: 78, utilizedCrore: 76, progress: 100, contractor: "AP State Civil Wing" },
  { id: "ip-004", name: "Tenali Bypass NH-216 Construction", type: "road" as const, location: "Tenali", status: "delayed" as const, startDate: "2024-04-22", endDate: "2026-06-30", budgetCrore: 312, utilizedCrore: 128, progress: 41, contractor: "PNC Infratech" },
  { id: "ip-005", name: "Sangam Jagarlamudi Water Treatment Plant", type: "water" as const, location: "Mangalagiri Mandal", status: "ongoing" as const, startDate: "2025-01-10", endDate: "2026-11-20", budgetCrore: 198, utilizedCrore: 122, progress: 62, contractor: "VA Tech Wabag" },
  { id: "ip-006", name: "Govt General Hospital – Trauma Block", type: "building" as const, location: "Guntur GGH", status: "ongoing" as const, startDate: "2024-11-05", endDate: "2026-08-30", budgetCrore: 92, utilizedCrore: 64, progress: 70, contractor: "Shapoorji Pallonji" },
  { id: "ip-007", name: "Nagarjuna Sagar Right Canal Lining", type: "irrigation" as const, location: "Sattenapalle / Piduguralla", status: "ongoing" as const, startDate: "2024-09-18", endDate: "2027-03-15", budgetCrore: 645, utilizedCrore: 232, progress: 36, contractor: "Megha Engineering" },
  { id: "ip-008", name: "Repalle Coastal Highway Widening", type: "road" as const, location: "Repalle–Nizampatnam", status: "planned" as const, startDate: "2026-08-01", endDate: "2028-12-30", budgetCrore: 425, utilizedCrore: 0, progress: 5, contractor: "Tender stage" },
  { id: "ip-009", name: "Guntur West Sewage Treatment Plant (40 MLD)", type: "water" as const, location: "Guntur West", status: "planned" as const, startDate: "2026-06-15", endDate: "2028-03-30", budgetCrore: 245, utilizedCrore: 18, progress: 12, contractor: "Tender awarded" },
  { id: "ip-010", name: "Mandal Skill Centres – 8 sites", type: "building" as const, location: "Multi-mandal", status: "ongoing" as const, startDate: "2025-02-20", endDate: "2026-09-10", budgetCrore: 56, utilizedCrore: 36, progress: 65, contractor: "AP Civil Supplies Wing" },
  { id: "ip-011", name: "Bapatla Coastal Embankment", type: "public" as const, location: "Bapatla", status: "ongoing" as const, startDate: "2025-04-04", endDate: "2026-12-30", budgetCrore: 138, utilizedCrore: 64, progress: 48, contractor: "AP Water Resources" },
  { id: "ip-012", name: "Narasaraopet Bus Terminal Upgrade", type: "building" as const, location: "Narasaraopet", status: "completed" as const, startDate: "2024-06-12", endDate: "2026-01-30", budgetCrore: 42, utilizedCrore: 41, progress: 100, contractor: "APSRTC Civil Cell" },
];

const GUNTUR_ROAD_CONDITIONS = [
  { area: "Guntur Urban Core", condition: "good" as const, score: 78, lengthKm: 142 },
  { area: "Brodipet–Arundelpet Corridor", condition: "fair" as const, score: 64, lengthKm: 38 },
  { area: "Mangalagiri NH-16", condition: "excellent" as const, score: 92, lengthKm: 26 },
  { area: "Tenali Town Roads", condition: "fair" as const, score: 58, lengthKm: 96 },
  { area: "Tenali Bypass (Under Const.)", condition: "poor" as const, score: 38, lengthKm: 22 },
  { area: "Narasaraopet Belt", condition: "good" as const, score: 72, lengthKm: 84 },
  { area: "Repalle Coastal", condition: "poor" as const, score: 42, lengthKm: 64 },
  { area: "Bapatla Mandal Roads", condition: "fair" as const, score: 56, lengthKm: 78 },
  { area: "Sattenapalle–Piduguralla", condition: "poor" as const, score: 36, lengthKm: 112 },
  { area: "Vinukonda Rural", condition: "critical" as const, score: 28, lengthKm: 88 },
  { area: "Chilakaluripet Junction", condition: "good" as const, score: 74, lengthKm: 32 },
  { area: "Ponnuru Connector", condition: "fair" as const, score: 52, lengthKm: 46 },
];

const KRISHNA_PROJECTS = [
  { id: "kr-ip-001", name: "Vijayawada Metro Rail – Phase 1", type: "public" as const, location: "Vijayawada City", status: "ongoing" as const, startDate: "2025-02-10", endDate: "2028-06-30", budgetCrore: 5960, utilizedCrore: 680, progress: 14, contractor: "Rail Vikas Nigam Ltd" },
  { id: "kr-ip-002", name: "Machilipatnam Port Expansion", type: "public" as const, location: "Machilipatnam", status: "ongoing" as const, startDate: "2024-07-01", endDate: "2027-12-30", budgetCrore: 5100, utilizedCrore: 1420, progress: 28, contractor: "AP Maritime Board" },
  { id: "kr-ip-003", name: "Krishna Barrage Modernisation", type: "bridge" as const, location: "Vijayawada", status: "ongoing" as const, startDate: "2025-01-20", endDate: "2026-10-30", budgetCrore: 210, utilizedCrore: 118, progress: 56, contractor: "NCC Limited" },
  { id: "kr-ip-004", name: "District Collectorate Modernisation", type: "building" as const, location: "Machilipatnam", status: "completed" as const, startDate: "2023-04-10", endDate: "2025-11-20", budgetCrore: 64, utilizedCrore: 63, progress: 100, contractor: "AP State Civil Wing" },
  { id: "kr-ip-005", name: "Gudivada–Bhimavaram Rail Doubling", type: "road" as const, location: "Gudivada", status: "delayed" as const, startDate: "2024-05-15", endDate: "2026-09-30", budgetCrore: 890, utilizedCrore: 310, progress: 34, contractor: "Indian Railways" },
  { id: "kr-ip-006", name: "GGH Vijayawada – Trauma & Cardiac Block", type: "building" as const, location: "Vijayawada", status: "ongoing" as const, startDate: "2024-10-08", endDate: "2026-07-30", budgetCrore: 118, utilizedCrore: 82, progress: 68, contractor: "Shapoorji Pallonji" },
  { id: "kr-ip-007", name: "Krishna Delta Canal Modernisation", type: "irrigation" as const, location: "Delta mandals", status: "ongoing" as const, startDate: "2024-11-01", endDate: "2027-05-15", budgetCrore: 780, utilizedCrore: 264, progress: 34, contractor: "Megha Engineering" },
  { id: "kr-ip-008", name: "Avanigadda Coastal Highway Widening", type: "road" as const, location: "Avanigadda–Nagayalanka", status: "planned" as const, startDate: "2026-09-01", endDate: "2029-01-30", budgetCrore: 356, utilizedCrore: 0, progress: 4, contractor: "Tender stage" },
  { id: "kr-ip-009", name: "Vijayawada West Sewage Treatment Plant (60 MLD)", type: "water" as const, location: "Vijayawada West", status: "planned" as const, startDate: "2026-05-10", endDate: "2028-08-30", budgetCrore: 312, utilizedCrore: 22, progress: 8, contractor: "Tender awarded" },
  { id: "kr-ip-010", name: "Mandal Skill Centres – 10 sites", type: "building" as const, location: "Multi-mandal", status: "ongoing" as const, startDate: "2025-03-12", endDate: "2026-10-05", budgetCrore: 64, utilizedCrore: 41, progress: 63, contractor: "AP Civil Supplies Wing" },
  { id: "kr-ip-011", name: "Kaikaluru Aquaculture Embankment", type: "public" as const, location: "Kaikaluru", status: "ongoing" as const, startDate: "2025-05-06", endDate: "2027-01-30", budgetCrore: 156, utilizedCrore: 58, progress: 37, contractor: "AP Water Resources" },
  { id: "kr-ip-012", name: "Gannavaram Airport Terminal Upgrade", type: "building" as const, location: "Gannavaram", status: "completed" as const, startDate: "2024-02-18", endDate: "2025-12-20", budgetCrore: 210, utilizedCrore: 206, progress: 100, contractor: "Airports Authority of India" },
];

const KRISHNA_ROAD_CONDITIONS = [
  { area: "Vijayawada Urban Core", condition: "good" as const, score: 76, lengthKm: 168 },
  { area: "Governorpet–Suryaraopet Corridor", condition: "fair" as const, score: 62, lengthKm: 42 },
  { area: "Gannavaram NH-16", condition: "excellent" as const, score: 90, lengthKm: 24 },
  { area: "Machilipatnam Town Roads", condition: "fair" as const, score: 60, lengthKm: 88 },
  { area: "Gudivada Bypass", condition: "good" as const, score: 70, lengthKm: 28 },
  { area: "Nuzvid Belt", condition: "fair" as const, score: 54, lengthKm: 96 },
  { area: "Avanigadda Coastal", condition: "poor" as const, score: 40, lengthKm: 72 },
  { area: "Kaikaluru Aquaculture Roads", condition: "poor" as const, score: 38, lengthKm: 64 },
  { area: "Nandigama–Jaggayyapeta", condition: "fair" as const, score: 56, lengthKm: 104 },
  { area: "Tiruvuru Rural", condition: "critical" as const, score: 30, lengthKm: 92 },
  { area: "Vuyyuru Junction", condition: "good" as const, score: 72, lengthKm: 30 },
  { area: "Mylavaram Connector", condition: "fair" as const, score: 50, lengthKm: 48 },
];

router.get("/infrastructure", (req, res) => {
  const slug = resolveDistrict(req);
  const cacheKey = `infrastructure-${slug}`;
  const cached = cache.get<object>(cacheKey);
  if (cached) return res.json(cached);

  const projects = slug === "krishna" ? KRISHNA_PROJECTS : GUNTUR_PROJECTS;
  const roadConditions = slug === "krishna" ? KRISHNA_ROAD_CONDITIONS : GUNTUR_ROAD_CONDITIONS;

  const totalProjects = projects.length;
  const ongoing = projects.filter((p) => p.status === "ongoing").length;
  const completed = projects.filter((p) => p.status === "completed").length;
  const planned = projects.filter((p) => p.status === "planned").length;
  const delayed = projects.filter((p) => p.status === "delayed").length;
  const totalBudgetCrore = projects.reduce((s, p) => s + p.budgetCrore, 0);
  const totalUtilizedCrore = projects.reduce((s, p) => s + p.utilizedCrore, 0);
  const utilizationPercent = Math.round((totalUtilizedCrore / totalBudgetCrore) * 1000) / 10;

  const totalKm = roadConditions.reduce((s, r) => s + r.lengthKm, 0);
  const avgScore = Math.round(roadConditions.reduce((s, r) => s + r.score * r.lengthKm, 0) / totalKm);
  const criticalKm = roadConditions.filter((r) => r.condition === "poor" || r.condition === "critical").reduce((s, r) => s + r.lengthKm, 0);

  const data = {
    summary: { totalProjects, ongoing, completed, planned, delayed, totalBudgetCrore, totalUtilizedCrore, utilizationPercent },
    projects,
    roadConditions,
    roadSummary: { totalKm, avgScore, criticalKm },
    lastUpdated: new Date().toISOString(),
  };

  cache.set(cacheKey, data, 30 * 60 * 1000);
  return res.json(data);
});

export default router;
