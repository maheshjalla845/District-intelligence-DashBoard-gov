import { Router } from "express";
import { db } from "@workspace/db";
import { alertsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { cache } from "../lib/cache";
import { logger } from "../lib/logger";
import { resolveDistrict } from "../lib/district";

const router = Router();

const DISTRICT_NAMES: Record<string, string> = { guntur: "Guntur", krishna: "Krishna" };

async function generateWeatherAlerts(district: string) {
  try {
    const { fetchLiveWeather } = await import("./weather");
    const weather = (await fetchLiveWeather(district)) as {
      temperature: number;
      humidity: number;
      windSpeed: number;
      rainfall: number;
      condition: string;
    };

    const districtName = DISTRICT_NAMES[district] ?? "Guntur";
    const autoAlerts: object[] = [];
    const now = new Date().toISOString();

    if (weather.temperature >= 42) {
      autoAlerts.push({
        id: `auto-heatwave-critical-${district}`,
        title: `Extreme Heatwave — ${weather.temperature}°C`,
        description: `Temperature has reached ${weather.temperature}°C in ${districtName}. NDMA advisory: Avoid outdoor exposure between 11 AM–4 PM. Carry water. Watch for heat stroke symptoms.`,
        severity: "critical",
        category: "Weather",
        issuedAt: now,
        validUntil: null,
      });
    } else if (weather.temperature >= 38) {
      autoAlerts.push({
        id: `auto-heatwave-warning-${district}`,
        title: `Heatwave Warning — ${weather.temperature}°C`,
        description: `Elevated temperatures of ${weather.temperature}°C recorded in ${districtName} district. Citizens advised to stay hydrated and avoid peak afternoon sun.`,
        severity: "warning",
        category: "Weather",
        issuedAt: now,
        validUntil: null,
      });
    }

    if (weather.rainfall > 50) {
      autoAlerts.push({
        id: `auto-heavy-rain-${district}`,
        title: `Heavy Rainfall Alert — ${weather.rainfall}mm/hr`,
        description: `Heavy rainfall of ${weather.rainfall}mm/hour recorded. Flash flood risk in low-lying areas. SDRF teams on standby.`,
        severity: "critical",
        category: "Weather",
        issuedAt: now,
        validUntil: null,
      });
    } else if (weather.rainfall > 15) {
      autoAlerts.push({
        id: `auto-moderate-rain-${district}`,
        title: `Moderate Rainfall — ${weather.rainfall}mm/hr`,
        description: `Moderate to heavy rainfall in ${districtName} area. Motorists advised to drive with caution. Drainage teams deployed.`,
        severity: "medium",
        category: "Weather",
        issuedAt: now,
        validUntil: null,
      });
    }

    if (weather.windSpeed > 60) {
      autoAlerts.push({
        id: `auto-strong-wind-${district}`,
        title: `Strong Wind Advisory — ${weather.windSpeed} km/h`,
        description: `Strong winds of ${weather.windSpeed} km/h recorded. Avoid coastal areas and open spaces. Secure loose outdoor objects.`,
        severity: "warning",
        category: "Weather",
        issuedAt: now,
        validUntil: null,
      });
    }

    return autoAlerts;
  } catch (err) {
    logger.warn({ err }, "Could not generate weather-based alerts");
    return [];
  }
}

router.get("/alerts", async (req, res) => {
  try {
    const district = resolveDistrict(req);
    const cacheKey = `alerts-${district}`;
    const cached = cache.get<object[]>(cacheKey);
    if (cached) return res.json(cached);

    const [dbAlerts, weatherAlerts] = await Promise.all([
      db.select().from(alertsTable).where(eq(alertsTable.district, district)).orderBy(alertsTable.issuedAt),
      generateWeatherAlerts(district),
    ]);

    const dbFormatted = dbAlerts.map((a) => ({
      id: a.id,
      title: a.title,
      description: a.description,
      severity: a.severity,
      category: a.category,
      issuedAt: a.issuedAt.toISOString(),
      validUntil: a.validUntil ? a.validUntil.toISOString() : undefined,
    }));

    const weatherAlertIds = new Set(weatherAlerts.map((a: any) => a.id));
    const heatwaveDbId = district === "krishna" ? "kr-alert-heatwave" : "alert-001";
    const filteredDb = dbFormatted.filter((a) => {
      if (a.id === heatwaveDbId && (weatherAlertIds.has(`auto-heatwave-critical-${district}`) || weatherAlertIds.has(`auto-heatwave-warning-${district}`))) return false;
      return true;
    });

    const severityOrder: Record<string, number> = { critical: 0, warning: 1, medium: 2, info: 3 };
    const all = [...weatherAlerts, ...filteredDb].sort(
      (a: any, b: any) => (severityOrder[a.severity] ?? 9) - (severityOrder[b.severity] ?? 9)
    );

    cache.set(cacheKey, all, 5 * 60 * 1000);
    return res.json(all);
  } catch (err) {
    req.log.error({ err }, "Failed to get alerts");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
