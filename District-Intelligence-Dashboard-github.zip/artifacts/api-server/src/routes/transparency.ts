import { Router } from "express";
import { cache } from "../lib/cache";
import { resolveDistrict } from "../lib/district";

const router = Router();

const GUNTUR_PROMISES = [
  { id: "p1", title: "Outer Ring Road Phase 2", category: "Infrastructure", completion: 72, status: "ongoing" as const, deadline: "Dec 2026" },
  { id: "p2", title: "Free Tap Water Connections – 100K homes", category: "Water", completion: 88, status: "ongoing" as const, deadline: "Aug 2026" },
  { id: "p3", title: "Smart Streetlights – Guntur Urban", category: "Smart City", completion: 100, status: "completed" as const, deadline: "Mar 2026" },
  { id: "p4", title: "200 Anganwadi Modernisation", category: "Welfare", completion: 95, status: "completed" as const, deadline: "Feb 2026" },
  { id: "p5", title: "Tenali Bypass Construction", category: "Roads", completion: 41, status: "delayed" as const, deadline: "Jun 2026" },
  { id: "p6", title: "District Skill Centre", category: "Education", completion: 65, status: "ongoing" as const, deadline: "Sep 2026" },
  { id: "p7", title: "Solar Pumps for 5,000 Farmers", category: "Agriculture", completion: 58, status: "ongoing" as const, deadline: "Nov 2026" },
  { id: "p8", title: "Mandal-level Mini Stadium (8 sites)", category: "Sports", completion: 25, status: "delayed" as const, deadline: "Mar 2027" },
  { id: "p9", title: "Free Bus Travel for Women", category: "Transport", completion: 100, status: "completed" as const, deadline: "Jan 2026" },
  { id: "p10", title: "PMAY-G Houses – 30,000 units", category: "Housing", completion: 76, status: "ongoing" as const, deadline: "Dec 2026" },
  { id: "p11", title: "Sewage Treatment Plant – Guntur West", category: "Sanitation", completion: 12, status: "pending" as const, deadline: "Mar 2027" },
  { id: "p12", title: "Free LPG Refills for BPL", category: "Welfare", completion: 92, status: "ongoing" as const, deadline: "Ongoing" },
];

const KRISHNA_PROMISES = [
  { id: "kr-p1", title: "Vijayawada Metro Rail Phase 1", category: "Infrastructure", completion: 14, status: "ongoing" as const, deadline: "Jun 2028" },
  { id: "kr-p2", title: "Machilipatnam Port Expansion", category: "Economy", completion: 28, status: "ongoing" as const, deadline: "Dec 2027" },
  { id: "kr-p3", title: "Smart Streetlights – Vijayawada Urban", category: "Smart City", completion: 100, status: "completed" as const, deadline: "Feb 2026" },
  { id: "kr-p4", title: "180 Anganwadi Modernisation", category: "Welfare", completion: 96, status: "completed" as const, deadline: "Jan 2026" },
  { id: "kr-p5", title: "Gudivada–Bhimavaram Rail Doubling", category: "Roads", completion: 34, status: "delayed" as const, deadline: "Sep 2026" },
  { id: "kr-p6", title: "District Skill Centre", category: "Education", completion: 63, status: "ongoing" as const, deadline: "Oct 2026" },
  { id: "kr-p7", title: "Solar Pumps for 4,000 Farmers", category: "Agriculture", completion: 61, status: "ongoing" as const, deadline: "Nov 2026" },
  { id: "kr-p8", title: "Mandal-level Mini Stadium (6 sites)", category: "Sports", completion: 30, status: "delayed" as const, deadline: "Apr 2027" },
  { id: "kr-p9", title: "Free Bus Travel for Women", category: "Transport", completion: 100, status: "completed" as const, deadline: "Jan 2026" },
  { id: "kr-p10", title: "PMAY-G Houses – 25,000 units", category: "Housing", completion: 79, status: "ongoing" as const, deadline: "Dec 2026" },
  { id: "kr-p11", title: "Sewage Treatment Plant – Vijayawada West", category: "Sanitation", completion: 8, status: "pending" as const, deadline: "Aug 2028" },
  { id: "kr-p12", title: "Free LPG Refills for BPL", category: "Welfare", completion: 94, status: "ongoing" as const, deadline: "Ongoing" },
];

const GUNTUR_GRIEVANCE_CATEGORIES = [
  { category: "Water Supply", count: 3420, resolved: 2980 },
  { category: "Power & Outages", count: 2890, resolved: 2640 },
  { category: "Sanitation", count: 2640, resolved: 2210 },
  { category: "Roads & Streets", count: 2380, resolved: 1980 },
  { category: "Revenue / Land", count: 2120, resolved: 1640 },
  { category: "Pension & Welfare", count: 1980, resolved: 1820 },
  { category: "Health Services", count: 1540, resolved: 1380 },
  { category: "Education", count: 1450, resolved: 1130 },
];

const KRISHNA_GRIEVANCE_CATEGORIES = [
  { category: "Water Supply", count: 2860, resolved: 2520 },
  { category: "Power & Outages", count: 2410, resolved: 2210 },
  { category: "Roads & Streets", count: 2680, resolved: 2280 },
  { category: "Sanitation", count: 2180, resolved: 1860 },
  { category: "Revenue / Land", count: 1940, resolved: 1560 },
  { category: "Port & Trade", count: 980, resolved: 780 },
  { category: "Pension & Welfare", count: 1720, resolved: 1590 },
  { category: "Health Services", count: 1380, resolved: 1240 },
];

router.get("/transparency", (req, res) => {
  const slug = resolveDistrict(req);
  const cacheKey = `transparency-${slug}`;
  const cached = cache.get<object>(cacheKey);
  if (cached) return res.json(cached);

  const now = new Date();
  const seed = now.getDate();

  const filedBase = slug === "krishna" ? 280 : 320;
  const months = ["May 25", "Jun 25", "Jul 25", "Aug 25", "Sep 25", "Oct 25", "Nov 25", "Dec 25", "Jan 26", "Feb 26", "Mar 26", "Apr 26"];
  const monthlyTrend = months.map((month, i) => {
    const filed = filedBase + i * 14 + (seed % 20);
    const responded = Math.round(filed * (0.78 + (i % 3) * 0.04));
    return { month, filed, responded, avgDays: 22 + (i % 5) };
  });

  const totalFiled = monthlyTrend.reduce((s, m) => s + m.filed, 0);
  const totalResponded = monthlyTrend.reduce((s, m) => s + m.responded, 0);
  const successRate = Math.round((totalResponded / totalFiled) * 1000) / 10;

  const promises = slug === "krishna" ? KRISHNA_PROMISES : GUNTUR_PROMISES;
  const completed = promises.filter((p) => p.status === "completed").length;
  const ongoing = promises.filter((p) => p.status === "ongoing").length;
  const pending = promises.filter((p) => p.status === "pending").length;
  const delayed = promises.filter((p) => p.status === "delayed").length;
  const overallCompletion = Math.round(promises.reduce((s, p) => s + p.completion, 0) / promises.length);

  const byCategory = slug === "krishna" ? KRISHNA_GRIEVANCE_CATEGORIES : GUNTUR_GRIEVANCE_CATEGORIES;
  const registeredBase = slug === "krishna" ? 16240 : 18420;
  const resolvedBase = slug === "krishna" ? 13980 : 15780;
  const grievances = {
    registered: registeredBase + seed * 12,
    resolved: resolvedBase + seed * 9,
    pending: 0,
    resolutionRate: 0,
    avgResolutionDays: slug === "krishna" ? 10 : 11,
    byCategory,
  };
  grievances.pending = grievances.registered - grievances.resolved;
  grievances.resolutionRate = Math.round((grievances.resolved / grievances.registered) * 1000) / 10;

  const data = {
    rti: {
      totalFiled,
      totalResponded,
      successRate,
      avgResponseDays: 24,
      within30Days: Math.round(totalResponded * 0.81),
      monthlyTrend,
    },
    promises,
    promiseSummary: { total: promises.length, completed, ongoing, pending, delayed, overallCompletion },
    grievances,
    lastUpdated: now.toISOString(),
  };

  cache.set(cacheKey, data, 30 * 60 * 1000);
  return res.json(data);
});

export default router;
