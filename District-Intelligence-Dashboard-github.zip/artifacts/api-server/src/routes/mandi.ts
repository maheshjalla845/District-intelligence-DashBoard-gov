import { Router } from "express";
import { db } from "@workspace/db";
import { mandiPricesTable } from "@workspace/db";
import { cache } from "../lib/cache";
import { eq } from "drizzle-orm";
import { resolveDistrict } from "../lib/district";

const router = Router();

const BASE_PRICES: Record<string, { base: number; volatility: number }> = {
  "mandi-001": { base: 18500, volatility: 600 },
  "mandi-002": { base: 14200, volatility: 400 },
  "mandi-003": { base: 6800, volatility: 200 },
  "mandi-004": { base: 5240, volatility: 150 },
  "mandi-005": { base: 8900, volatility: 300 },
  "mandi-006": { base: 1850, volatility: 60 },
  "mandi-007": { base: 2200, volatility: 50 },
  "mandi-008": { base: 12400, volatility: 400 },
  "mandi-009": { base: 1480, volatility: 120 },
  "mandi-010": { base: 1200, volatility: 80 },
  "kr-mandi-001": { base: 2280, volatility: 50 },
  "kr-mandi-002": { base: 6800, volatility: 500 },
  "kr-mandi-003": { base: 2450, volatility: 100 },
  "kr-mandi-004": { base: 345, volatility: 12 },
  "kr-mandi-005": { base: 48000, volatility: 1800 },
  "kr-mandi-006": { base: 12800, volatility: 400 },
  "kr-mandi-007": { base: 18100, volatility: 550 },
  "kr-mandi-008": { base: 6650, volatility: 200 },
  "kr-mandi-009": { base: 5180, volatility: 150 },
  "kr-mandi-010": { base: 1350, volatility: 90 },
};

function getLivePrice(id: string, dbPrice: number): { price: number; change: number; changePercent: number } {
  const meta = BASE_PRICES[id];
  if (!meta) return { price: dbPrice, change: 0, changePercent: 0 };

  const minuteSeed = Math.floor(Date.now() / (30 * 60 * 1000));
  const hashSeed = id.split("").reduce((acc, c) => acc + c.charCodeAt(0), minuteSeed);
  const rand = ((Math.sin(hashSeed) + 1) / 2) * 2 - 1;

  const change = Math.round(rand * meta.volatility);
  const newPrice = Math.max(meta.base * 0.7, meta.base + change);
  const changePercent = parseFloat(((change / meta.base) * 100).toFixed(2));

  return { price: Math.round(newPrice), change, changePercent };
}

router.get("/mandi", async (req, res) => {
  try {
    const district = resolveDistrict(req);
    const cacheKey = `mandi-${district}`;
    const cached = cache.get<object[]>(cacheKey);
    if (cached) return res.json(cached);

    const prices = await db
      .select()
      .from(mandiPricesTable)
      .where(eq(mandiPricesTable.district, district))
      .orderBy(mandiPricesTable.crop);

    const live = prices.map((p) => {
      const { price, change, changePercent } = getLivePrice(p.id, p.price);
      return {
        id: p.id,
        crop: p.crop,
        variety: p.variety,
        price,
        unit: p.unit,
        market: p.market,
        change,
        changePercent,
        updatedAt: new Date().toISOString(),
      };
    });

    cache.set(cacheKey, live, 30 * 60 * 1000);
    return res.json(live);
  } catch (err) {
    req.log.error({ err }, "Failed to get mandi prices");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
