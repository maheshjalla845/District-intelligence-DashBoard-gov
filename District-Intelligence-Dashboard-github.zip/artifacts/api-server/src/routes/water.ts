import { Router } from "express";
import { cache } from "../lib/cache";
import { resolveDistrict } from "../lib/district";

const router = Router();

const GUNTUR_SUPPLY_AREAS_META = [
  { area: "Guntur City (Urban)", source: "municipal", baseHours: 6, baseStatus: "normal" as const },
  { area: "Mangalagiri", source: "canal", baseHours: 5, baseStatus: "normal" as const, shortageBelow: 35 },
  { area: "Tenali", source: "canal", baseHours: 5, baseStatus: "normal" as const },
  { area: "Narasaraopet", source: "borewell", baseHours: 2, baseStatus: "shortage" as const },
  { area: "Bapatla", source: "municipal", baseHours: 6, baseStatus: "normal" as const },
  { area: "Sattenapalle", source: "borewell", baseHours: 3, baseStatus: "shortage" as const, disruptionBelow: 30 },
  { area: "Ponnur", source: "canal", baseHours: 4, baseStatus: "normal" as const },
  { area: "Repalle", source: "borewell", baseHours: 2, baseStatus: "shortage" as const },
];

const KRISHNA_SUPPLY_AREAS_META = [
  { area: "Vijayawada City (Urban)", source: "municipal", baseHours: 7, baseStatus: "normal" as const },
  { area: "Machilipatnam", source: "canal", baseHours: 5, baseStatus: "normal" as const, shortageBelow: 35 },
  { area: "Gudivada", source: "canal", baseHours: 5, baseStatus: "normal" as const },
  { area: "Nuzvid", source: "borewell", baseHours: 3, baseStatus: "shortage" as const },
  { area: "Gannavaram", source: "municipal", baseHours: 6, baseStatus: "normal" as const },
  { area: "Nandigama", source: "borewell", baseHours: 3, baseStatus: "shortage" as const, disruptionBelow: 30 },
  { area: "Avanigadda", source: "canal", baseHours: 4, baseStatus: "normal" as const },
  { area: "Kaikaluru", source: "borewell", baseHours: 2, baseStatus: "shortage" as const },
];

router.get("/water", async (req, res) => {
  try {
    const slug = resolveDistrict(req);
    const cacheKey = `water-${slug}`;
    const cached = cache.get<object>(cacheKey);
    if (cached) return res.json(cached);

    const now = new Date();
    const hour = now.getHours();
    const dayOfYear = Math.floor((now.getTime() - new Date(now.getFullYear(), 0, 0).getTime()) / 86400000);
    const isMonsoon = now.getMonth() >= 5 && now.getMonth() <= 9;
    const seed = dayOfYear % 30;

    const reservoirName = slug === "krishna" ? "Krishna Barrage" : "Prakasam Barrage";
    const fullReservoirLevel = slug === "krishna" ? 8.5 : 12.09;
    const capacityTMC = slug === "krishna" ? 12.5 : 17.43;

    const baseLevel = isMonsoon
      ? fullReservoirLevel * 0.86 + (seed % 10) * (slug === "krishna" ? 0.09 : 0.12)
      : fullReservoirLevel * 0.5 + (seed % 15) * (slug === "krishna" ? 0.13 : 0.18);
    const currentLevel = parseFloat(Math.min(baseLevel, fullReservoirLevel).toFixed(2));
    const storageTMC = parseFloat(((currentLevel / fullReservoirLevel) * capacityTMC).toFixed(2));
    const percentFilled = parseFloat(((currentLevel / fullReservoirLevel) * 100).toFixed(1));
    const inflow = isMonsoon ? 3800 + (seed % 20) * 170 : 300 + (seed % 10) * 42;
    const outflow = isMonsoon ? 3500 + (seed % 15) * 110 : 260 + (seed % 8) * 28;
    const damStatus = percentFilled >= 75 ? "High" : percentFilled >= 40 ? "Normal" : "Low";

    const supplyAreasMeta = slug === "krishna" ? KRISHNA_SUPPLY_AREAS_META : GUNTUR_SUPPLY_AREAS_META;
    const supplyAreas = supplyAreasMeta.map((m) => {
      const shortageBelow = "shortageBelow" in m ? m.shortageBelow : undefined;
      const disruptionBelow = "disruptionBelow" in m ? m.disruptionBelow : undefined;
      let status: string = m.baseStatus;
      let supplyHours = m.baseHours;
      let tankerDeployed = m.baseStatus !== "normal";
      let tankerCount = tankerDeployed ? 4 : 0;

      if (disruptionBelow !== undefined) {
        status = percentFilled < disruptionBelow ? "disruption" : "shortage";
        supplyHours = percentFilled < disruptionBelow ? 1 : 3;
        tankerDeployed = true;
        tankerCount = 6;
      } else if (shortageBelow !== undefined) {
        status = percentFilled < shortageBelow ? "shortage" : "normal";
        supplyHours = percentFilled < shortageBelow ? 3 : m.baseHours;
        tankerDeployed = percentFilled < shortageBelow;
        tankerCount = tankerDeployed ? 4 : 0;
      } else if (m.baseStatus === "shortage") {
        tankerCount = 8;
      }

      return {
        area: m.area,
        status,
        source: m.source,
        supplyHours,
        lastSupply: status === "normal" ? `Today ${hour < 9 ? "5:00 AM" : "7:00 AM"}` : "Yesterday 6:00 PM",
        tankerDeployed,
        tankerCount,
      };
    });

    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const rainfallData: number[] = [8, 5, 12, 18, 42, 125, 198, 215, 142, 68, 22, 10];
    const storageData: number[] =
      slug === "krishna"
        ? [3.4, 3.0, 2.8, 2.5, 3.2, 5.8, 10.4, 12.9, 11.4, 8.3, 6.1, 4.4]
        : [4.2, 3.8, 3.5, 3.1, 4.0, 7.2, 12.8, 15.9, 14.1, 10.3, 7.6, 5.4];
    const currentMonth = now.getMonth();
    const rainfallTrend = Array.from({ length: 12 }, (_, i) => {
      const mIdx = (currentMonth - 11 + i + 12) % 12;
      return {
        month: monthNames[mIdx],
        rainfall: rainfallData[mIdx] + (seed % 5) - 2,
        storage: parseFloat((storageData[mIdx] + (seed % 3) * 0.1).toFixed(1)),
      };
    });

    const shortage = supplyAreas.filter((a) => a.status === "shortage" || a.status === "disruption");
    const overallStatus = shortage.length >= 4 ? "disruption" : shortage.length >= 2 ? "shortage" : "normal";
    const totalTankersDeployed = supplyAreas.reduce((s, a) => s + a.tankerCount, 0);

    const data = {
      prakasam: {
        name: reservoirName,
        currentLevel,
        fullReservoirLevel,
        storageTMC,
        capacityTMC,
        percentFilled,
        inflow,
        outflow,
        status: damStatus,
        lastUpdated: now.toISOString(),
      },
      supplyAreas,
      rainfallTrend,
      overallStatus,
      totalTankersDeployed,
      lastUpdated: now.toISOString(),
    };

    cache.set(cacheKey, data, 15 * 60 * 1000);
    return res.json(data);
  } catch (err) {
    req.log.error({ err }, "Failed to get water data");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
