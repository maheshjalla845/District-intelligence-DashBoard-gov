import { Router } from "express";
import { cache } from "../lib/cache";
import { resolveDistrict } from "../lib/district";

const router = Router();

router.get("/traffic", (req, res) => {
  const slug = resolveDistrict(req);
  const cacheKey = `traffic-${slug}`;
  const cached = cache.get<object>(cacheKey);
  if (cached) return res.json(cached);

  const now = new Date();
  const hour = now.getHours();
  const minute = now.getMinutes();

  let baseCongestion = 35;
  if (hour >= 8 && hour <= 10) baseCongestion = slug === "krishna" ? 82 : 78;
  else if (hour >= 17 && hour <= 20) baseCongestion = slug === "krishna" ? 88 : 84;
  else if (hour >= 11 && hour <= 16) baseCongestion = 52;
  else if (hour >= 21 || hour <= 6) baseCongestion = 22;
  const currentCongestion = Math.min(95, Math.max(15, baseCongestion + (minute % 12) - 6));

  const congestionLevel: "low" | "moderate" | "high" | "severe" =
    currentCongestion >= 75 ? "severe" : currentCongestion >= 55 ? "high" : currentCongestion >= 35 ? "moderate" : "low";

  const avgSpeed = Math.round(60 - currentCongestion * 0.45);

  const hourlyTrend = Array.from({ length: 24 }, (_, h) => {
    let c = 30;
    if (h >= 8 && h <= 10) c = slug === "krishna" ? 82 : 78;
    else if (h >= 17 && h <= 20) c = slug === "krishna" ? 88 : 84;
    else if (h >= 11 && h <= 16) c = 52;
    else if (h >= 21 || h <= 6) c = 22;
    return { hour: `${String(h).padStart(2, "0")}:00`, congestion: c + ((h * 7) % 8) - 4 };
  });

  const heatmap =
    slug === "krishna"
      ? [
          { area: "Governorpet Main Rd", congestion: Math.min(95, currentCongestion + 14), condition: "fair", speed: Math.round(avgSpeed - 9) },
          { area: "Benz Circle", congestion: Math.min(95, currentCongestion + 22), condition: "fair", speed: Math.round(avgSpeed - 14) },
          { area: "Patamata Junction", congestion: Math.min(95, currentCongestion + 20), condition: "good", speed: Math.round(avgSpeed - 13) },
          { area: "Gannavaram NH-16", congestion: Math.max(20, currentCongestion - 18), condition: "excellent", speed: Math.round(avgSpeed + 18) },
          { area: "Machilipatnam Town", congestion: Math.min(85, currentCongestion + 6), condition: "fair", speed: Math.round(avgSpeed - 5) },
          { area: "Gudivada Bypass", congestion: Math.max(15, currentCongestion - 26), condition: "poor", speed: Math.round(avgSpeed + 6) },
          { area: "Nuzvid Centre", congestion: currentCongestion - 4, condition: "good", speed: avgSpeed + 2 },
          { area: "Avanigadda Coastal Rd", congestion: Math.max(15, currentCongestion - 24), condition: "poor", speed: Math.round(avgSpeed + 7) },
          { area: "Vuyyuru Junction", congestion: currentCongestion - 6, condition: "fair", speed: avgSpeed + 3 },
          { area: "Nandigama Junction", congestion: Math.max(20, currentCongestion - 20), condition: "poor", speed: Math.round(avgSpeed + 6) },
          { area: "Jaggayyapeta Junction", congestion: Math.min(80, currentCongestion + 2), condition: "good", speed: avgSpeed - 1 },
          { area: "Tiruvuru Connector", congestion: Math.max(15, currentCongestion - 30), condition: "critical", speed: Math.round(avgSpeed + 10) },
        ]
      : [
          { area: "Brodipet Main Rd", congestion: Math.min(95, currentCongestion + 12), condition: "fair", speed: Math.round(avgSpeed - 8) },
          { area: "Arundelpet Junction", congestion: Math.min(95, currentCongestion + 18), condition: "fair", speed: Math.round(avgSpeed - 12) },
          { area: "Naaz Centre", congestion: Math.min(95, currentCongestion + 22), condition: "good", speed: Math.round(avgSpeed - 15) },
          { area: "Mangalagiri NH-16", congestion: Math.max(20, currentCongestion - 18), condition: "excellent", speed: Math.round(avgSpeed + 18) },
          { area: "Tenali Town", congestion: Math.min(85, currentCongestion + 8), condition: "fair", speed: Math.round(avgSpeed - 6) },
          { area: "Tenali Bypass", congestion: Math.max(15, currentCongestion - 28), condition: "poor", speed: Math.round(avgSpeed + 5) },
          { area: "Narasaraopet Centre", congestion: currentCongestion - 4, condition: "good", speed: avgSpeed + 2 },
          { area: "Repalle Coastal Rd", congestion: Math.max(15, currentCongestion - 25), condition: "poor", speed: Math.round(avgSpeed + 8) },
          { area: "Bapatla Bus Stand", congestion: currentCongestion - 8, condition: "fair", speed: avgSpeed + 4 },
          { area: "Sattenapalle Junction", congestion: Math.max(20, currentCongestion - 20), condition: "poor", speed: Math.round(avgSpeed + 6) },
          { area: "Chilakaluripet Junction", congestion: Math.min(80, currentCongestion + 4), condition: "good", speed: avgSpeed - 2 },
          { area: "Vinukonda Bypass", congestion: Math.max(15, currentCongestion - 30), condition: "critical", speed: Math.round(avgSpeed + 10) },
        ];

  const normalizedHeatmap = heatmap.map((p) => ({
    ...p,
    congestion: Math.max(0, Math.min(100, p.congestion)),
    speed: Math.max(8, p.speed),
  }));

  const incidents =
    slug === "krishna"
      ? [
          { location: "Benz Circle", type: "Signal failure", severity: "medium" as const, eta: "~20 min" },
          { location: "Machilipatnam Town Centre", type: "Truck breakdown", severity: "high" as const, eta: "~40 min" },
          { location: "Gannavaram NH-16 KM 8", type: "Minor accident", severity: "low" as const, eta: "Cleared" },
          { location: "Governorpet Main Rd", type: "Road repair", severity: "medium" as const, eta: "Ongoing" },
        ]
      : [
          { location: "Arundelpet Junction", type: "Signal failure", severity: "medium" as const, eta: "~25 min" },
          { location: "Tenali Town Centre", type: "Truck breakdown", severity: "high" as const, eta: "~45 min" },
          { location: "Mangalagiri NH-16 KM 14", type: "Minor accident", severity: "low" as const, eta: "Cleared" },
          { location: "Brodipet Main Rd", type: "Road repair", severity: "medium" as const, eta: "Ongoing" },
        ];

  const data = {
    currentCongestion: Math.round(currentCongestion),
    congestionLevel,
    avgSpeed,
    peakHours: ["08:00–10:00", "17:00–20:00"],
    hourlyTrend,
    heatmap: normalizedHeatmap,
    incidents,
    lastUpdated: now.toISOString(),
  };

  cache.set(cacheKey, data, 5 * 60 * 1000);
  return res.json(data);
});

export default router;
