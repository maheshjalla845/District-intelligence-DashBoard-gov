# District Intelligence Dashboard

A full-stack dashboard giving a real-time overview of a district: weather, air quality, water & dams, power, traffic, health, police & safety, economy, mandi (market) prices, housing schemes, governance & transparency, demographics, mandal-wise data, district comparison, and local news.

## Tech stack

- **Monorepo:** pnpm workspaces, TypeScript 5.9, Node.js 24
- **Frontend:** React + Vite (`artifacts/district-dashboard`)
- **Backend:** Express 5 (`artifacts/api-server`), Pino logging, node-cron
- **Database:** PostgreSQL + Drizzle ORM (`lib/db`)
- **API contract:** OpenAPI spec → Orval-generated React Query hooks and Zod schemas (`lib/api-spec`, `lib/api-client-react`, `lib/api-zod`)
- **Auth:** Clerk

## Project structure

```
artifacts/
  api-server/          Express API (routes for each dashboard section)
  district-dashboard/  React frontend
  mockup-sandbox/      UI prototyping sandbox
lib/
  api-spec/            OpenAPI spec + codegen config
  api-client-react/    Generated API client hooks
  api-zod/             Generated Zod schemas/types
  db/                  Drizzle schema & config
scripts/               Utility scripts
```

## Getting started

### Prerequisites
- Node.js 24+
- [pnpm](https://pnpm.io/) (`npm i -g pnpm`)
- A PostgreSQL database
- API keys: [OpenWeather](https://openweathermap.org/api), [Clerk](https://clerk.com)

### Setup

```bash
git clone <your-repo-url>
cd District-Intelligence-Dashboard
pnpm install
cp .env.example .env      # then fill in your values
```

### Database

```bash
pnpm --filter @workspace/db run push
```

### Run

In two terminals (export the variables from `.env` in each, or use a tool like `dotenv`):

```bash
# API server
pnpm --filter @workspace/api-server run dev

# Frontend
pnpm --filter @workspace/district-dashboard run dev
```

### Other commands

```bash
pnpm run typecheck                                # typecheck everything
pnpm run build                                    # typecheck + build all packages
pnpm --filter @workspace/api-spec run codegen     # regenerate API client/Zod from OpenAPI
```

## Environment variables

See [`.env.example`](.env.example). **Never commit your real `.env` file.**

## License

MIT
